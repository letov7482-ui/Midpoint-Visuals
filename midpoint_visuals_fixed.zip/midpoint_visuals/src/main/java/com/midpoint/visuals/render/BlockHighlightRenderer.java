package com.midpoint.visuals.render;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.HighlightStyle;
import com.midpoint.visuals.config.MidpointConfig;
import com.midpoint.visuals.config.ModuleState;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Random;

/**
 * Draws a neon outline + optional animated fill on the block currently under
 * the player's crosshair (i.e. the vanilla client-side ray trace result).
 * This deliberately never renders through blocks - it only ever draws the
 * single block the client's own hit result already resolved to.
 *
 * Batched into a single draw call per frame using a shared VertexConsumer
 * from the WorldRenderContext's buffer source (RenderType.lines() for the
 * outline, a translucent quad RenderType for the fill).
 */
public final class BlockHighlightRenderer {

	private static final Random RANDOM = new Random();
	private static int cachedRandomColor = 0xFF9B30FF;
	private static long lastRandomRoll = 0L;

	private BlockHighlightRenderer() {
	}

	public static void render(WorldRenderContext context) {
		MidpointConfig cfg = ConfigManager.CONFIG;
		if (!cfg.blockHighlightState.isActive()) {
			return;
		}

		Minecraft client = Minecraft.getInstance();
		if (client.hitResult == null || client.hitResult.getType() != HitResult.Type.BLOCK) {
			return;
		}
		if (client.level == null || client.player == null) {
			return;
		}

		BlockHitResult blockHit = (BlockHitResult) client.hitResult;
		BlockPos pos = blockHit.getBlockPos();
		BlockState state = client.level.getBlockState(pos);
		if (state.isAir()) {
			return;
		}

		VoxelShape shape = state.getShape(client.level, pos);
		AABB box = (shape.isEmpty() ? new AABB(0, 0, 0, 1, 1, 1) : shape.bounds()).move(pos);

		Vec3 camera = context.camera().getPosition();
		PoseStack poseStack = context.matrixStack();
		if (poseStack == null) {
			return;
		}

		poseStack.pushPose();
		poseStack.translate(-camera.x, -camera.y, -camera.z);

		int color = resolveColor(cfg);
		float r = ((color >> 16) & 0xFF) / 255f;
		float g = ((color >> 8) & 0xFF) / 255f;
		float b = (color & 0xFF) / 255f;

		MultiBufferSource.BufferSource buffers = context.consumers() != null
				? (MultiBufferSource.BufferSource) context.consumers()
				: client.renderBuffers().bufferSource();

		RenderSystem.disableDepthTest();
		RenderSystem.enableBlend();

		// --- Outline: single batched line strip via RenderType.lines() ---
		VertexConsumer lines = buffers.getBuffer(RenderType.lines());
		drawBoxOutline(poseStack, lines, box, r, g, b, 1.0f);

		// --- Fill: translucent quads, style depends on config ---
		HighlightStyle style = cfg.blockHighlightStyle;
		VertexConsumer fill = buffers.getBuffer(RenderType.translucent());
		float alpha = switch (style) {
			case SOLID -> 0.20f;
			case COSMIC -> 0.28f;
			case BLACKHOLE -> 0.35f;
		};
		drawBoxFaces(poseStack, fill, box, r, g, b, alpha);

		if (style != HighlightStyle.SOLID) {
			drawAnimatedSpecks(poseStack, fill, box, pos, style);
		}

		buffers.endBatch(RenderType.lines());
		buffers.endBatch(RenderType.translucent());

		RenderSystem.disableBlend();
		RenderSystem.enableDepthTest();

		poseStack.popPose();
	}

	private static int resolveColor(MidpointConfig cfg) {
		if (cfg.blockHighlightState == ModuleState.RANDOM) {
			long now = System.currentTimeMillis();
			if (now - lastRandomRoll > 3000L) {
				cachedRandomColor = 0xFF000000
						| (RANDOM.nextInt(256) << 16)
						| (RANDOM.nextInt(256) << 8)
						| RANDOM.nextInt(256);
				lastRandomRoll = now;
			}
			return cachedRandomColor;
		}
		return cfg.blockHighlightColor;
	}

	private static void drawBoxOutline(PoseStack poseStack, VertexConsumer consumer, AABB box,
			float r, float g, float b, float a) {
		var pose = poseStack.last();
		var mat = pose.pose();

		double x0 = box.minX, y0 = box.minY, z0 = box.minZ;
		double x1 = box.maxX, y1 = box.maxY, z1 = box.maxZ;

		// 12 edges of the box, each as a 2-vertex line.
		double[][] edges = {
				{x0, y0, z0, x1, y0, z0}, {x1, y0, z0, x1, y0, z1}, {x1, y0, z1, x0, y0, z1}, {x0, y0, z1, x0, y0, z0},
				{x0, y1, z0, x1, y1, z0}, {x1, y1, z0, x1, y1, z1}, {x1, y1, z1, x0, y1, z1}, {x0, y1, z1, x0, y1, z0},
				{x0, y0, z0, x0, y1, z0}, {x1, y0, z0, x1, y1, z0}, {x1, y0, z1, x1, y1, z1}, {x0, y0, z1, x0, y1, z1}
		};

		for (double[] e : edges) {
			float nx = (float) (e[3] - e[0]);
			float ny = (float) (e[4] - e[1]);
			float nz = (float) (e[5] - e[2]);
			consumer.addVertex(mat, (float) e[0], (float) e[1], (float) e[2])
					.setColor(r, g, b, a)
					.setNormal(pose, nx, ny, nz);
			consumer.addVertex(mat, (float) e[3], (float) e[4], (float) e[5])
					.setColor(r, g, b, a)
					.setNormal(pose, nx, ny, nz);
		}
	}

	private static void drawBoxFaces(PoseStack poseStack, VertexConsumer consumer, AABB box,
			float r, float g, float b, float a) {
		var pose = poseStack.last();
		var mat = pose.pose();

		float x0 = (float) box.minX, y0 = (float) box.minY, z0 = (float) box.minZ;
		float x1 = (float) box.maxX, y1 = (float) box.maxY, z1 = (float) box.maxZ;

		quad(consumer, mat, pose, x0, y0, z0, x1, y0, z0, x1, y1, z0, x0, y1, z0, r, g, b, a);
		quad(consumer, mat, pose, x1, y0, z1, x0, y0, z1, x0, y1, z1, x1, y1, z1, r, g, b, a);
		quad(consumer, mat, pose, x0, y0, z1, x0, y0, z0, x0, y1, z0, x0, y1, z1, r, g, b, a);
		quad(consumer, mat, pose, x1, y0, z0, x1, y0, z1, x1, y1, z1, x1, y1, z0, r, g, b, a);
		quad(consumer, mat, pose, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, r, g, b, a);
		quad(consumer, mat, pose, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, r, g, b, a);
	}

	private static void quad(VertexConsumer consumer, org.joml.Matrix4f mat, PoseStack.Pose pose,
			float x0, float y0, float z0, float x1, float y1, float z1,
			float x2, float y2, float z2, float x3, float y3, float z3,
			float r, float g, float b, float a) {
		consumer.addVertex(mat, x0, y0, z0).setColor(r, g, b, a).setNormal(pose, 0, 1, 0);
		consumer.addVertex(mat, x1, y1, z1).setColor(r, g, b, a).setNormal(pose, 0, 1, 0);
		consumer.addVertex(mat, x2, y2, z2).setColor(r, g, b, a).setNormal(pose, 0, 1, 0);
		consumer.addVertex(mat, x3, y3, z3).setColor(r, g, b, a).setNormal(pose, 0, 1, 0);
	}

	/**
	 * Cheap deterministic "starfield" effect for the Cosmic / Black Hole styles:
	 * a handful of small bright specks scattered inside the block, seeded by
	 * block position so they don't jitter between frames, with a slow pulse.
	 */
	private static void drawAnimatedSpecks(PoseStack poseStack, VertexConsumer consumer, AABB box,
			BlockPos pos, HighlightStyle style) {
		var pose = poseStack.last();
		var mat = pose.pose();

		Random seeded = new Random(pos.asLong());
		float time = (System.currentTimeMillis() % 100000L) / 1000f;
		int speckCount = style == HighlightStyle.BLACKHOLE ? 10 : 14;

		for (int i = 0; i < speckCount; i++) {
			float baseX = seeded.nextFloat();
			float baseY = seeded.nextFloat();
			float baseZ = seeded.nextFloat();
			float pulse = (float) (0.5 + 0.5 * Math.sin(time * 2f + i));

			float cx = (float) (box.minX + baseX * box.getXsize());
			float cy = (float) (box.minY + baseY * box.getYsize());
			float cz = (float) (box.minZ + baseZ * box.getZsize());
			float size = 0.02f + 0.015f * pulse;

			float r, g, b;
			if (style == HighlightStyle.BLACKHOLE) {
				r = 0.05f + 0.1f * pulse;
				g = 0.0f;
				b = 0.05f + 0.15f * pulse;
			} else {
				r = 0.6f + 0.4f * pulse;
				g = 0.6f + 0.4f * pulse;
				b = 1.0f;
			}
			float alpha = 0.5f + 0.4f * pulse;

			quad(consumer, mat, pose,
					cx - size, cy - size, cz, cx + size, cy - size, cz,
					cx + size, cy + size, cz, cx - size, cy + size, cz,
					r, g, b, alpha);
		}
	}
}
