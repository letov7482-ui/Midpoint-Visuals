package com.midpoint.visuals.util;

import com.midpoint.visuals.MidpointVisuals;
import com.midpoint.visuals.config.ConfigManager;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import com.mojang.blaze3d.platform.InputConstants;

/**
 * All keybinds are registered as vanilla rebindable {@link KeyMapping}s so
 * they show up in Controls > Key Binds and work identically on touch-based
 * launchers that expose a virtual keyboard (Pojav / Zalith / FCL / Mojo).
 */
public final class KeyBindings {

    public static KeyMapping openMenu;
    public static KeyMapping ggBind;
    public static KeyMapping dance1;
    public static KeyMapping dance2;

    private KeyBindings() {}

    public static void register() {
        int menuCode = ConfigManager.get().menuKeyCode;
        int ggCode = ConfigManager.get().ggKeyCode;
        int d1Code = ConfigManager.get().dance1KeyCode;
        int d2Code = ConfigManager.get().dance2KeyCode;

        openMenu = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.midpoint_visuals.open_menu",
                InputConstants.Type.KEYSYM,
                menuCode,
                "category.midpoint_visuals.main"
        ));

        ggBind = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.midpoint_visuals.gg",
                InputConstants.Type.KEYSYM,
                ggCode,
                "category.midpoint_visuals.main"
        ));

        dance1 = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.midpoint_visuals.dance1",
                InputConstants.Type.KEYSYM,
                d1Code,
                "category.midpoint_visuals.main"
        ));

        dance2 = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.midpoint_visuals.dance2",
                InputConstants.Type.KEYSYM,
                d2Code,
                "category.midpoint_visuals.main"
        ));

        MidpointVisuals.LOGGER.info("Midpoint Visuals key bindings registered");
    }
}
