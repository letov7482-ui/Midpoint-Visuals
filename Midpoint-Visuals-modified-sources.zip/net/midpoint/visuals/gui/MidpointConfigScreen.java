package net.midpoint.visuals.gui;

import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.config.ModConfig;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Simple settings screen exposing the main modules, hat picker, and theme
 * selector without adding an external config library.
 *
 * @author Midpoint
 */
public class MidpointConfigScreen extends class_437 {

	private final class_437 parent;

	public MidpointConfigScreen(class_437 parent) {
		super(class_2561.method_43470("Midpoint Visuals"));
		this.parent = parent;
	}

	@Override
	protected void method_25426() {
		ModConfig cfg = ConfigManager.CONFIG;
		int centerX = this.field_22789 / 2;
		int leftX = centerX - 112;
		int rightX = centerX + 4;
		int startY = 36;
		int buttonWidth = 108;
		int row = 0;

		addToggle(leftX, startY + row++ * 24, buttonWidth, "Environment", () -> cfg.environmentEnabled, v -> cfg.environmentEnabled = v);
		addToggle(rightX, startY + 0 * 24, buttonWidth, "HUD", () -> cfg.hudEnabled, v -> cfg.hudEnabled = v);
		addToggle(leftX, startY + 1 * 24, buttonWidth, "HUD Drag", () -> cfg.hudDragEnabled, v -> cfg.hudDragEnabled = v);
		addToggle(rightX, startY + 1 * 24, buttonWidth, "Glow FX", () -> cfg.fxEnabled, v -> cfg.fxEnabled = v);
		addToggle(leftX, startY + 2 * 24, buttonWidth, "Hats", () -> cfg.hatsEnabled, v -> cfg.hatsEnabled = v);
		addCycle(leftX, startY + 3 * 24, buttonWidth, "Hat", new String[] {"none", "top_hat", "fedora", "crown", "wizard", "cowboy"},
				() -> cfg.selectedHat, v -> cfg.selectedHat = v);
		addToggle(rightX, startY + 2 * 24, buttonWidth, "Pearl Arc", () -> cfg.pearlTrajectoryEnabled, v -> cfg.pearlTrajectoryEnabled = v);
		addToggle(rightX, startY + 3 * 24, buttonWidth, "Cube Fog", () -> cfg.cubeFogEnabled, v -> cfg.cubeFogEnabled = v);
		addToggle(leftX, startY + 4 * 24, buttonWidth, "Block Outline", () -> cfg.blockOutlineEnabled, v -> cfg.blockOutlineEnabled = v);
		addCycle(rightX, startY + 4 * 24, buttonWidth, "Theme", new String[] {"space", "aurora", "sunset"},
				() -> cfg.blockOutlineTheme, v -> cfg.blockOutlineTheme = v);
		addToggle(leftX, startY + 5 * 24, buttonWidth, "Emotes", () -> cfg.emotesEnabled, v -> cfg.emotesEnabled = v);
		addToggle(rightX, startY + 5 * 24, buttonWidth, "Glow Shader", () -> cfg.shaderGlowEnabled, v -> cfg.shaderGlowEnabled = v);

		this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), b -> {
					ConfigManager.save();
					this.field_22787.method_1507(this.parent);
				})
				.method_46434(centerX - 54, startY + 6 * 24 + 10, 108, 20)
				.method_46431());
	}

	private void addToggle(int x, int y, int width, String label,
			java.util.function.BooleanSupplier getter, java.util.function.Consumer<Boolean> setter) {
		class_4185 button = class_4185.method_46430(class_2561.method_43470(format(label, getter.getAsBoolean())), b -> {
					boolean next = !getter.getAsBoolean();
					setter.accept(next);
					b.method_25355(class_2561.method_43470(format(label, next)));
				})
				.method_46434(x, y, width, 20)
				.method_46431();
		this.method_37063(button);
	}

	private void addCycle(int x, int y, int width, String label, String[] values,
			java.util.function.Supplier<String> getter, java.util.function.Consumer<String> setter) {
		class_4185 button = class_4185.method_46430(class_2561.method_43470(formatValue(label, getter.get())), b -> {
					String current = getter.get();
					int idx = 0;
					for (int i = 0; i < values.length; i++) {
						if (values[i].equals(current)) {
							idx = i;
							break;
						}
					}
					String next = values[(idx + 1) % values.length];
					setter.accept(next);
					b.method_25355(class_2561.method_43470(formatValue(label, next)));
				})
				.method_46434(x, y, width, 20)
				.method_46431();
		this.method_37063(button);
	}

	private String format(String label, boolean value) {
		return label + ": " + (value ? "ON" : "OFF");
	}

	private String formatValue(String label, String value) {
		return label + ": " + value;
	}

	@Override
	public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
		this.method_25420(graphics, mouseX, mouseY, partialTick);
		super.method_25394(graphics, mouseX, mouseY, partialTick);
		graphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 16, 0xFFFFFF);
		graphics.method_27534(this.field_22793, class_2561.method_43470("Chat to drag the HUD"), this.field_22789 / 2, 24, 0xB5B9C6);
	}

	@Override
	public boolean method_25421() {
		return false;
	}

	@Override
	public void method_25419() {
		ConfigManager.save();
		this.field_22787.method_1507(this.parent);
	}
}
