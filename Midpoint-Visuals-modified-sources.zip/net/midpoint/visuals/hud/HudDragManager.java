package net.midpoint.visuals.hud;

import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.config.ModConfig;
import net.minecraft.class_310;

/**
 * Tracks a simple HUD drag interaction while the chat screen is open.
 *
 * @author Midpoint
 */
public final class HudDragManager {

	private static boolean dragging;
	private static int dragOffsetX;
	private static int dragOffsetY;

	private HudDragManager() {
	}

	public static boolean isDragging() {
		return dragging;
	}

	public static boolean beginDrag(double mouseX, double mouseY) {
		ModConfig cfg = ConfigManager.CONFIG;
		if (!cfg.hudEnabled || !cfg.hudDragEnabled) {
			return false;
		}
		if (!HudOverlay.contains(mouseX, mouseY)) {
			return false;
		}

		dragging = true;
		dragOffsetX = (int) Math.round(mouseX) - cfg.hudX;
		dragOffsetY = (int) Math.round(mouseY) - cfg.hudY;
		return true;
	}

	public static boolean drag(double mouseX, double mouseY, int screenWidth, int screenHeight) {
		if (!dragging) {
			return false;
		}

		ModConfig cfg = ConfigManager.CONFIG;
		int newX = (int) Math.round(mouseX) - dragOffsetX;
		int newY = (int) Math.round(mouseY) - dragOffsetY;

		int maxX = Math.max(0, screenWidth - HudOverlay.getPanelWidth());
		int maxY = Math.max(0, screenHeight - HudOverlay.getPanelHeight());

		cfg.hudX = clamp(newX, 0, maxX);
		cfg.hudY = clamp(newY, 0, maxY);
		return true;
	}

	public static boolean endDrag() {
		boolean wasDragging = dragging;
		dragging = false;
		ConfigManager.save();
		return wasDragging;
	}

	private static int clamp(int value, int min, int max) {
		return Math.max(min, Math.min(max, value));
	}
}
