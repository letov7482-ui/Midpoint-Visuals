package net.midpoint.visuals.hud;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.config.ModConfig;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/**
 * Renders a cleaner floating HUD panel with a brighter accent, layered
 * background, and a compact status readout. The panel can be dragged while
 * the chat screen is open.
 *
 * @author Midpoint
 */
public final class HudOverlay {

	private static final int PANEL_WIDTH = 132;
	private static final int PANEL_HEIGHT = 54;

	private HudOverlay() {
	}

	public static void register() {
		HudRenderCallback.EVENT.register(HudOverlay::render);
	}

	public static int getPanelWidth() {
		return PANEL_WIDTH;
	}

	public static int getPanelHeight() {
		return PANEL_HEIGHT;
	}

	public static boolean contains(double mouseX, double mouseY) {
		ModConfig cfg = ConfigManager.CONFIG;
		return mouseX >= cfg.hudX && mouseX <= cfg.hudX + PANEL_WIDTH
				&& mouseY >= cfg.hudY && mouseY <= cfg.hudY + PANEL_HEIGHT;
	}

	private static void render(class_332 graphics, class_9779 deltaTracker) {
		ModConfig cfg = ConfigManager.CONFIG;
		if (!cfg.hudEnabled) {
			return;
		}

		class_310 client = class_310.method_1551();
		if (client.field_1724 == null) {
			return;
		}

		int x = cfg.hudX;
		int y = cfg.hudY;
		int accent = cfg.hudAccentColor;
		int accentSoft = tint(accent, 0.42f);
		int accentBright = tint(accent, 1.18f);

		graphics.method_25294(x, y, x + PANEL_WIDTH, y + PANEL_HEIGHT, 0xCC0B0E14);
		graphics.method_25294(x + 1, y + 1, x + PANEL_WIDTH - 1, y + PANEL_HEIGHT - 1, 0x8610151D);
		graphics.method_25294(x, y, x + PANEL_WIDTH, y + 2, accentBright);
		graphics.method_25294(x, y + PANEL_HEIGHT - 1, x + PANEL_WIDTH, y + PANEL_HEIGHT, 0x55101826);
		graphics.method_25294(x, y, x + 2, y + PANEL_HEIGHT, accentSoft);

		graphics.method_51439(client.field_1772, class_2561.method_43470("Midpoint Visuals"), x + 6, y + 6, 0xF3F6FF, false);
		graphics.method_51439(client.field_1772, class_2561.method_43470("drag chat HUD"), x + 6, y + 18, 0xB5B9C6, false);

		float health = client.field_1724.method_6032();
		float maxHealth = client.field_1724.method_6063();
		float ratio = maxHealth > 0 ? clamp01(health / maxHealth) : 0f;

		int barX = x + 6;
		int barY = y + 32;
		int barWidth = PANEL_WIDTH - 12;
		int barHeight = 8;
		int filled = Math.round(barWidth * ratio);

		graphics.method_25294(barX, barY, barX + barWidth, barY + barHeight, 0x55121822);
		graphics.method_25294(barX, barY, barX + filled, barY + barHeight, accent);

		String hpText = "HP " + Math.round(health) + "/" + Math.round(maxHealth);
		graphics.method_51439(client.field_1772, class_2561.method_43470(hpText), x + PANEL_WIDTH - 34, y + 18, 0xFFFFFF, false);
	}

	private static float clamp01(float value) {
		return value < 0f ? 0f : Math.min(1f, value);
	}

	private static int tint(int color, float scale) {
		int a = (color >>> 24) & 0xFF;
		int r = (int) Math.min(255, ((color >>> 16) & 0xFF) * scale);
		int g = (int) Math.min(255, ((color >>> 8) & 0xFF) * scale);
		int b = (int) Math.min(255, (color & 0xFF) * scale);
		return (a << 24) | (r << 16) | (g << 8) | b;
	}
}
