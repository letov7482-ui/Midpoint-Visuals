package net.midpoint.visuals.shader;

import java.util.function.Supplier;
import net.minecraft.class_10156;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_2960;

/**
 * Keeps a stable entry point for the custom glow shader.
 *
 * <p>In Minecraft 1.21.4, modded core shaders are loaded from the vanilla
 * resource-pack pipeline, so Fabric's old CoreShaderRegistrationCallback is
 * no longer used here.</p>
 *
 * @author Midpoint
 */
public final class ShaderManager {

	public static final class_2960 GLOW_SHADER_ID =
			class_2960.method_60655("midpoint_visuals", "midpoint_glow");

	private ShaderManager() {
	}

	public static void init() {
		// No-op on 1.21.4: the shader is discovered from assets/midpoint_visuals/shaders/core.
	}

	public static Supplier<class_10156> glowShaderSupplier() {
		return () -> null;
	}

	public static class_293 glowFormat() {
		return class_290.field_1576;
	}
}
