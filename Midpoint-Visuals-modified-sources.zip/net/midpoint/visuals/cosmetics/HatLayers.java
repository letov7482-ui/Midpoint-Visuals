package net.midpoint.visuals.cosmetics;

import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.class_2960;
import net.minecraft.class_5601;

/**
 * Registers a small collection of cosmetic hats.
 *
 * @author Midpoint
 */
public final class HatLayers {

	public static final class_5601 TOP_HAT = new class_5601(
			class_2960.method_60655("midpoint_visuals", "top_hat"), "main");
	public static final class_5601 FEDORA = new class_5601(
			class_2960.method_60655("midpoint_visuals", "fedora"), "main");
	public static final class_5601 CROWN = new class_5601(
			class_2960.method_60655("midpoint_visuals", "crown"), "main");
	public static final class_5601 WIZARD = new class_5601(
			class_2960.method_60655("midpoint_visuals", "wizard"), "main");
	public static final class_5601 COWBOY = new class_5601(
			class_2960.method_60655("midpoint_visuals", "cowboy"), "main");

	private HatLayers() {
	}

	public static void register() {
		EntityModelLayerRegistry.registerModelLayer(TOP_HAT, HatModel::createTopHatLayerDefinition);
		EntityModelLayerRegistry.registerModelLayer(FEDORA, HatModel::createFedoraLayerDefinition);
		EntityModelLayerRegistry.registerModelLayer(CROWN, HatModel::createCrownLayerDefinition);
		EntityModelLayerRegistry.registerModelLayer(WIZARD, HatModel::createWizardLayerDefinition);
		EntityModelLayerRegistry.registerModelLayer(COWBOY, HatModel::createCowboyLayerDefinition);
	}
}
