package net.midpoint.visuals.cosmetics;

import java.util.HashMap;
import java.util.Map;
import net.midpoint.visuals.config.ConfigManager;
import net.minecraft.class_10055;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_591;

/**
 * Renders a chosen cosmetic hat on top of the player's head.
 *
 * @author Midpoint
 */
public class HatFeatureRenderer extends class_3887<class_10055, class_591> {

	private static final class_2960 HAT_TEXTURE =
			class_2960.method_60655("midpoint_visuals", "textures/models/hats/top_hat.png");

	private final Map<String, HatModel> models = new HashMap<>();

	public HatFeatureRenderer(class_3883<class_10055, class_591> parent,
			HatModel topHat, HatModel fedora, HatModel crown, HatModel wizard, HatModel cowboy) {
		super(parent);
		this.models.put("top_hat", topHat);
		this.models.put("fedora", fedora);
		this.models.put("crown", crown);
		this.models.put("wizard", wizard);
		this.models.put("cowboy", cowboy);
	}

	@Override
	public void render(class_4587 poseStack, class_4597 bufferSource, int packedLight,
			class_10055 renderState, float yRot, float xRot) {
		if (!ConfigManager.CONFIG.hatsEnabled) {
			return;
		}
		String selectedHat = ConfigManager.CONFIG.selectedHat;
		if ("none".equals(selectedHat)) {
			return;
		}

		HatModel model = models.get(selectedHat);
		if (model == null) {
			model = models.get("top_hat");
		}
		if (model == null) {
			return;
		}

		class_591 playerModel = method_17165();

		poseStack.method_22903();
		playerModel.field_3398.method_22703(poseStack);
		poseStack.method_22904(0.0, -0.05, 0.0);

		var consumer = bufferSource.getBuffer(class_1921.method_23578(HAT_TEXTURE));
		model.part().method_22698(poseStack, consumer, packedLight, class_4608.field_21444);

		poseStack.method_22909();
	}
}
