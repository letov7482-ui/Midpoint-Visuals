package net.midpoint.visuals.cosmetics;

import net.minecraft.class_5603;
import net.minecraft.class_5606;
import net.minecraft.class_5607;
import net.minecraft.class_5609;
import net.minecraft.class_5610;
import net.minecraft.class_630;

/**
 * Cosmetic hat mesh collection. Each style uses the same texture atlas but a
 * different baked shape so the selection feels more alive than a single cube.
 *
 * @author Midpoint
 */
public final class HatModel {

	public static final String LAYER_NAME = "midpoint_hat";

	private final class_630 root;

	public HatModel(class_630 root) {
		this.root = root;
	}

	public static class_5607 createTopHatLayerDefinition() {
		return buildLayer(64, 32, parts -> {
			parts.method_32117("crown",
					class_5606.method_32108().method_32101(0, 0).method_32097(-3.5f, -8.5f, -3.5f, 7.0f, 6.0f, 7.0f),
					class_5603.method_32090(0.0f, 0.0f, 0.0f));
			parts.method_32117("brim",
					class_5606.method_32108().method_32101(0, 13).method_32097(-5.5f, -2.0f, -5.5f, 11.0f, 1.0f, 11.0f),
					class_5603.method_32090(0.0f, -7.0f, 0.0f));
		});
	}

	public static class_5607 createFedoraLayerDefinition() {
		return buildLayer(64, 32, parts -> {
			parts.method_32117("crown",
					class_5606.method_32108().method_32101(0, 0).method_32097(-3.0f, -8.25f, -3.0f, 6.0f, 5.0f, 6.0f),
					class_5603.method_32090(0.0f, 0.0f, 0.0f));
			parts.method_32117("brim",
					class_5606.method_32108().method_32101(0, 11).method_32097(-4.75f, -2.0f, -4.75f, 9.5f, 1.0f, 9.5f),
					class_5603.method_32090(0.0f, -6.75f, 0.0f));
		});
	}

	public static class_5607 createCrownLayerDefinition() {
		return buildLayer(64, 32, parts -> {
			parts.method_32117("band",
					class_5606.method_32108().method_32101(24, 0).method_32097(-3.2f, -7.25f, -3.2f, 6.4f, 1.0f, 6.4f),
					class_5603.method_32090(0.0f, 0.0f, 0.0f));
			parts.method_32117("points",
					class_5606.method_32108().method_32101(0, 0).method_32097(-4.0f, -8.75f, -4.0f, 8.0f, 2.0f, 8.0f),
					class_5603.method_32090(0.0f, -0.5f, 0.0f));
			parts.method_32117("gem",
					class_5606.method_32108().method_32101(32, 0).method_32097(-1.0f, -10.5f, -1.0f, 2.0f, 2.0f, 2.0f),
					class_5603.method_32090(0.0f, 0.0f, 0.0f));
		});
	}

	public static class_5607 createWizardLayerDefinition() {
		return buildLayer(64, 32, parts -> {
			parts.method_32117("hat",
					class_5606.method_32108().method_32101(0, 0).method_32097(-3.5f, -8.5f, -3.5f, 7.0f, 7.0f, 7.0f),
					class_5603.method_32090(0.0f, 0.0f, 0.0f));
			parts.method_32117("tip",
					class_5606.method_32108().method_32101(22, 0).method_32097(-1.25f, -11.0f, -1.25f, 2.5f, 4.0f, 2.5f),
					class_5603.method_32090(0.0f, 0.0f, 0.0f));
		});
	}

	public static class_5607 createCowboyLayerDefinition() {
		return buildLayer(64, 32, parts -> {
			parts.method_32117("crown",
					class_5606.method_32108().method_32101(0, 0).method_32097(-2.75f, -8.0f, -2.75f, 5.5f, 4.5f, 5.5f),
					class_5603.method_32090(0.0f, 0.0f, 0.0f));
			parts.method_32117("brim",
					class_5606.method_32108().method_32101(0, 10).method_32097(-6.5f, -2.25f, -6.5f, 13.0f, 1.0f, 13.0f),
					class_5603.method_32090(0.0f, -6.25f, 0.0f));
		});
	}

	private static class_5607 buildLayer(int texWidth, int texHeight, java.util.function.Consumer<class_5610> partsConsumer) {
		class_5609 mesh = new class_5609();
		class_5610 parts = mesh.method_32111();
		partsConsumer.accept(parts);
		return class_5607.method_32110(mesh, texWidth, texHeight);
	}

	public class_630 part() {
		return root;
	}
}
