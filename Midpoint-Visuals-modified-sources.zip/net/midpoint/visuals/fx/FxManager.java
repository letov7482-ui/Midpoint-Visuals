package net.midpoint.visuals.fx;

import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.config.ModConfig;
import net.minecraft.class_1657;
import net.minecraft.class_310;

/**
 * Registers the glow particle factory and periodically spawns particles
 * around the local player when the {@code fx} module is enabled.
 *
 * @author Midpoint
 */
public final class FxManager {

	private FxManager() {
	}

	public static void registerClient() {
		ParticleFactoryRegistry.getInstance().register(ModParticles.MIDPOINT_GLOW, GlowParticle.FactoryProvider::new);
	}

	/** Called once per client tick. */
	public static void tick() {
		ModConfig cfg = ConfigManager.CONFIG;
		if (!cfg.fxEnabled) {
			return;
		}
		class_310 client = class_310.method_1551();
		class_1657 player = client.field_1724;
		if (player == null || client.field_1687 == null) {
			return;
		}
		for (int i = 0; i < Math.max(0, cfg.particlesPerTick); i++) {
			double ox = (client.field_1687.field_9229.method_43058() - 0.5) * 0.6;
			double oy = client.field_1687.field_9229.method_43058() * 1.8;
			double oz = (client.field_1687.field_9229.method_43058() - 0.5) * 0.6;
			client.field_1687.method_8406(ModParticles.MIDPOINT_GLOW,
					player.method_23317() + ox, player.method_23318() + oy, player.method_23321() + oz,
					0.0, 0.01, 0.0);
		}
	}
}
