package net.midpoint.visuals.fx;

import net.minecraft.class_2400;
import net.minecraft.class_3999;
import net.minecraft.class_4002;
import net.minecraft.class_4003;
import net.minecraft.class_638;
import net.minecraft.class_703;
import net.minecraft.class_707;

/**
 * A small additive glow speck used by the {@code fx} module. Colour is
 * supplied by {@link net.midpoint.visuals.config.ModConfig#particleColor}.
 *
 * @author Midpoint
 */
public class GlowParticle extends class_4003 {

	protected GlowParticle(class_638 level, double x, double y, double z,
			double dx, double dy, double dz, int argb) {
		super(level, x, y, z, dx, dy, dz);
		this.field_3852 = dx;
		this.field_3869 = dy * 0.2 + 0.02;
		this.field_3850 = dz;
		this.field_17867 = 0.08f + this.field_3840.method_43057() * 0.05f;
		this.field_3847 = 20 + this.field_3840.method_43048(10);
		this.field_3862 = false;
		float r = ((argb >> 16) & 0xFF) / 255f;
		float g = ((argb >> 8) & 0xFF) / 255f;
		float b = (argb & 0xFF) / 255f;
		this.method_3084(r, g, b);
		this.method_3083(0.9f);
	}

	@Override
	public class_3999 method_18122() {
		return class_3999.field_17829;
	}

	@Override
	public void method_3070() {
		super.method_3070();
		this.field_3841 = 1.0f - ((float) this.field_3866 / this.field_3847);
	}

	public static class FactoryProvider implements class_707<class_2400> {
		private final class_4002 sprites;

		public FactoryProvider(class_4002 sprites) {
			this.sprites = sprites;
		}

		@Override
		public class_703 createParticle(class_2400 type, class_638 level,
				double x, double y, double z, double dx, double dy, double dz) {
			int argb = net.midpoint.visuals.config.ConfigManager.CONFIG.particleColor;
			GlowParticle particle = new GlowParticle(level, x, y, z, dx, dy, dz, argb);
			particle.method_18140(sprites);
			return particle;
		}
	}
}
