package net.midpoint.visuals.fx;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.class_2378;
import net.minecraft.class_2400;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

/**
 * Registers Midpoint Visuals' custom glow particle type.
 *
 * @author Midpoint
 */
public final class ModParticles {

	public static final class_2400 MIDPOINT_GLOW = FabricParticleTypes.simple();

	private ModParticles() {
	}

	public static void register() {
		class_2378.method_10230(
				class_7923.field_41180,
				class_2960.method_60655("midpoint_visuals", "midpoint_glow"),
				MIDPOINT_GLOW
		);
	}
}
