package net.midpoint.visuals.core;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.cosmetics.HatLayers;
import net.midpoint.visuals.emotes.EmoteManager;
import net.midpoint.visuals.environment.EnvironmentModule;
import net.midpoint.visuals.fx.FxManager;
import net.midpoint.visuals.fx.ModParticles;
import net.midpoint.visuals.gui.MidpointConfigScreen;
import net.midpoint.visuals.hud.HudOverlay;
import net.midpoint.visuals.shader.ShaderManager;
import net.midpoint.visuals.world.BlockOutlineRenderer;
import net.midpoint.visuals.world.CubeFogRenderer;
import net.midpoint.visuals.world.PearlTrajectoryRenderer;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;

/**
 * Midpoint Visuals - client entrypoint. Initializes every module and wires
 * the shared client tick loop.
 *
 * @author Midpoint
 */
public class MidpointVisualsClient implements ClientModInitializer {

	private static final class_304 OPEN_GUI = new class_304(
			"key.midpoint_visuals.open_gui",
			class_3675.class_307.field_1668,
			class_3675.field_32021,
			"category.midpoint_visuals");

	@Override
	public void onInitializeClient() {
		ConfigManager.load();

		ModParticles.register();
		HatLayers.register();
		ShaderManager.init();

		FxManager.registerClient();
		HudOverlay.register();
		PearlTrajectoryRenderer.register();
		CubeFogRenderer.register();
		BlockOutlineRenderer.register();
		EmoteManager.registerClient();
		KeyBindingHelper.registerKeyBinding(OPEN_GUI);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			EnvironmentModule.tick();
			FxManager.tick();

			while (OPEN_GUI.method_1436()) {
				class_310 mc = class_310.method_1551();
				if (mc.field_1755 == null) {
					mc.method_1507(new MidpointConfigScreen(null));
				}
			}
		});
	}
}
