package net.midpoint.visuals.world;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.midpoint.visuals.config.ConfigManager;
import net.minecraft.class_1657;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import org.joml.Matrix4f;

/**
 * Draws a predicted ender pearl arc from the player's current aim.
 *
 * @author Midpoint
 */
public final class PearlTrajectoryRenderer {

	private PearlTrajectoryRenderer() {
	}

	public static void register() {
		WorldRenderEvents.AFTER_ENTITIES.register(context -> {
			if (!ConfigManager.CONFIG.pearlTrajectoryEnabled) {
				return;
			}

			class_310 client = class_310.method_1551();
			if (client.field_1724 == null || context.consumers() == null) {
				return;
			}

			class_243 camera = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());
			List<class_243> points = computeTrajectory(client.field_1724, 28);
			if (points.size() < 2) {
				return;
			}

			Matrix4f matrix = context.positionMatrix();
			var consumer = context.consumers().getBuffer(class_1921.method_23594());
			int[] start = rgba(255, 122, 255, 255);
			int[] end = rgba(95, 233, 255, 255);

			for (int i = 0; i < points.size() - 1; i++) {
				float t = i / (float) (points.size() - 1);
				int[] c = mix(start, end, t);
				class_243 a = points.get(i);
				class_243 b = points.get(i + 1);
				vertex(consumer, matrix, a, camera, c);
				vertex(consumer, matrix, b, camera, c);
			}
		});
	}

	
	private static List<class_243> computeTrajectory(class_1657 player, int maxSteps) {
		List<class_243> points = new ArrayList<>();

		class_243 position = new class_243(player.method_23317(), player.method_23318() + 1.62, player.method_23321());
		class_243 velocity = player.method_5724(1.0f).method_1021(1.5);
		points.add(position);

		for (int i = 0; i < maxSteps; i++) {
			class_243 next = position.method_1031(velocity);
			points.add(next);

			velocity = new class_243(velocity.field_1352 * 0.99, velocity.field_1351 - 0.03, velocity.field_1350 * 0.99);
			position = next;
		}

		return points;
	}


	private static void vertex(class_4588 consumer, Matrix4f matrix, class_243 pos, class_243 camera, int[] rgba) {
		consumer.method_22918(matrix,
				(float) (pos.field_1352 - camera.field_1352),
				(float) (pos.field_1351 - camera.field_1351),
				(float) (pos.field_1350 - camera.field_1350))
				.method_22915(rgba[0], rgba[1], rgba[2], rgba[3])
				.method_1344();
	}

	private static int[] rgba(int r, int g, int b, int a) {
		return new int[] { r, g, b, a };
	}

	private static int[] mix(int[] a, int[] b, float t) {
		int r = (int) class_3532.method_16436(t, a[0], b[0]);
		int g = (int) class_3532.method_16436(t, a[1], b[1]);
		int bl = (int) class_3532.method_16436(t, a[2], b[2]);
		int al = (int) class_3532.method_16436(t, a[3], b[3]);
		return new int[] { r, g, bl, al };
	}
}
