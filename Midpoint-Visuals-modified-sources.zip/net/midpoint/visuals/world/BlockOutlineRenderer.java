package net.midpoint.visuals.world;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.midpoint.visuals.config.ConfigManager;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

/**
 * Draws a custom rainbow-like outline around the targeted block.
 *
 * @author Midpoint
 */
public final class BlockOutlineRenderer {

	private BlockOutlineRenderer() {
	}

	public static void register() {
		WorldRenderEvents.AFTER_ENTITIES.register(context -> {
			if (!ConfigManager.CONFIG.blockOutlineEnabled || context.consumers() == null) {
				return;
			}

			class_310 client = class_310.method_1551();
			if (client.field_1724 == null) {
				return;
			}
			if (client.field_1765 == null || !(client.field_1765 instanceof class_3965 hit)) {
				return;
			}

			Matrix4f matrix = context.positionMatrix();
			var consumer = context.consumers().getBuffer(class_1921.method_23594());
			class_2338 pos = hit.method_17777();
			class_243 camera = new class_243(client.field_1724.method_23317(), client.field_1724.method_23318(), client.field_1724.method_23321());

			double x = pos.method_10263() - camera.field_1352;
			double y = pos.method_10264() - camera.field_1351;
			double z = pos.method_10260() - camera.field_1350;

			float time = (System.currentTimeMillis() % 3000L) / 3000.0f;
			int[] c1 = themeColor(ConfigManager.CONFIG.blockOutlineTheme, time);
			int[] c2 = themeColor(ConfigManager.CONFIG.blockOutlineTheme, time + 0.33f);
			int[] c3 = themeColor(ConfigManager.CONFIG.blockOutlineTheme, time + 0.66f);

			drawBox(consumer, matrix, x, y, z, 1.0, c1[0], c1[1], c1[2], c1[3]);
			drawInsetBox(consumer, matrix, x, y, z, 0.985, c2[0], c2[1], c2[2], c2[3]);
			drawInsetBox(consumer, matrix, x, y, z, 1.015, c3[0], c3[1], c3[2], c3[3]);
		});
	}

	private static int[] themeColor(String theme, float t) {
		int phase = (int) (t * 3.0f) % 3;
		if ("aurora".equals(theme)) {
			return switch (phase) {
				case 0 -> rgba(70, 255, 215, 200);
				case 1 -> rgba(140, 255, 115, 170);
				default -> rgba(255, 255, 255, 150);
			};
		}
		if ("sunset".equals(theme)) {
			return switch (phase) {
				case 0 -> rgba(255, 146, 61, 200);
				case 1 -> rgba(255, 70, 104, 170);
				default -> rgba(194, 76, 255, 150);
			};
		}
		return switch (phase) {
			case 0 -> rgba(125, 69, 255, 210);
			case 1 -> rgba(63, 227, 255, 180);
			default -> rgba(255, 107, 214, 160);
		};
	}

	private static void drawBox(class_4588 consumer, Matrix4f matrix,
			double x, double y, double z, double size, int r, int g, int b, int a) {
		double maxX = x + size;
		double maxY = y + size;
		double maxZ = z + size;

		line(consumer, matrix, x, y, z, maxX, y, z, r, g, b, a);
		line(consumer, matrix, maxX, y, z, maxX, maxY, z, r, g, b, a);
		line(consumer, matrix, maxX, maxY, z, x, maxY, z, r, g, b, a);
		line(consumer, matrix, x, maxY, z, x, y, z, r, g, b, a);

		line(consumer, matrix, x, y, maxZ, maxX, y, maxZ, r, g, b, a);
		line(consumer, matrix, maxX, y, maxZ, maxX, maxY, maxZ, r, g, b, a);
		line(consumer, matrix, maxX, maxY, maxZ, x, maxY, maxZ, r, g, b, a);
		line(consumer, matrix, x, maxY, maxZ, x, y, maxZ, r, g, b, a);

		line(consumer, matrix, x, y, z, x, y, maxZ, r, g, b, a);
		line(consumer, matrix, maxX, y, z, maxX, y, maxZ, r, g, b, a);
		line(consumer, matrix, maxX, maxY, z, maxX, maxY, maxZ, r, g, b, a);
		line(consumer, matrix, x, maxY, z, x, maxY, maxZ, r, g, b, a);
	}

	private static void drawInsetBox(class_4588 consumer, Matrix4f matrix,
			double x, double y, double z, double inset, int r, int g, int b, int a) {
		drawBox(consumer, matrix, x + inset * 0.01, y + inset * 0.01, z + inset * 0.01,
				1.0 + (inset - 1.0), r, g, b, a);
	}

	private static void line(class_4588 consumer, Matrix4f matrix,
			double x1, double y1, double z1, double x2, double y2, double z2,
			int r, int g, int b, int a) {
		consumer.method_22918(matrix, (float) x1, (float) y1, (float) z1).method_22915(r, g, b, a).method_1344();
		consumer.method_22918(matrix, (float) x2, (float) y2, (float) z2).method_22915(r, g, b, a).method_1344();
	}

	private static int[] rgba(int r, int g, int b, int a) {
		return new int[] { r, g, b, a };
	}
}
