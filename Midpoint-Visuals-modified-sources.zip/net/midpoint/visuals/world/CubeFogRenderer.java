package net.midpoint.visuals.world;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.midpoint.visuals.config.ConfigManager;
import net.minecraft.class_1921;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4588;
import org.joml.Matrix4f;

/**
 * A drifting fog made out of tiny translucent cube outlines cycling through
 * yellow, black, red, and purple.
 *
 * @author Midpoint
 */
public final class CubeFogRenderer {

	private static final int[] PALETTE = {
			0xFFE9D84A,
			0xFF121212,
			0xFFE93A3A,
			0xFF9B30FF
	};

	private CubeFogRenderer() {
	}

	public static void register() {
		WorldRenderEvents.AFTER_ENTITIES.register(context -> {
			if (!ConfigManager.CONFIG.cubeFogEnabled || context.consumers() == null) {
				return;
			}

			class_310 client = class_310.method_1551();
			if (client.field_1724 == null) {
				return;
			}

			Matrix4f matrix = context.positionMatrix();
			var consumer = context.consumers().getBuffer(class_1921.method_23594());
						long time = System.currentTimeMillis() / 80L;

			for (int i = 0; i < 18; i++) {
				double angle = (time * 0.04) + i * 1.1;
				double radius = 4.0 + (i % 4) * 0.8;
				double x = Math.cos(angle) * radius + Math.sin(time * 0.02 + i) * 0.3;
				double y = Math.sin(angle * 0.7 + i * 0.25) * 1.2 + Math.sin(time * 0.015 + i * 0.4) * 0.4;
				double z = Math.sin(angle) * radius + Math.cos(time * 0.02 + i) * 0.3;
				double size = 0.16 + (i % 3) * 0.05;
				int color = paletteColor(i, time);
				drawCube(consumer, matrix, x, y, z, size, color);
			}
		});
	}

	private static int paletteColor(int index, long time) {
		int offset = (int) ((time / 5L + index) % PALETTE.length);
		int color = PALETTE[offset];
		int alpha = index % 2 == 0 ? 90 : 120;
		return (alpha << 24) | (color & 0x00FFFFFF);
	}

	private static void drawCube(class_4588 consumer, Matrix4f matrix, double x, double y, double z, double size, int rgba) {
		double minX = x - size;
		double minY = y - size;
		double minZ = z - size;
		double maxX = x + size;
		double maxY = y + size;
		double maxZ = z + size;

		line(consumer, matrix, minX, minY, minZ, maxX, minY, minZ, rgba);
		line(consumer, matrix, maxX, minY, minZ, maxX, maxY, minZ, rgba);
		line(consumer, matrix, maxX, maxY, minZ, minX, maxY, minZ, rgba);
		line(consumer, matrix, minX, maxY, minZ, minX, minY, minZ, rgba);

		line(consumer, matrix, minX, minY, maxZ, maxX, minY, maxZ, rgba);
		line(consumer, matrix, maxX, minY, maxZ, maxX, maxY, maxZ, rgba);
		line(consumer, matrix, maxX, maxY, maxZ, minX, maxY, maxZ, rgba);
		line(consumer, matrix, minX, maxY, maxZ, minX, minY, maxZ, rgba);

		line(consumer, matrix, minX, minY, minZ, minX, minY, maxZ, rgba);
		line(consumer, matrix, maxX, minY, minZ, maxX, minY, maxZ, rgba);
		line(consumer, matrix, maxX, maxY, minZ, maxX, maxY, maxZ, rgba);
		line(consumer, matrix, minX, maxY, minZ, minX, maxY, maxZ, rgba);
	}

	private static void line(class_4588 consumer, Matrix4f matrix,
			double x1, double y1, double z1, double x2, double y2, double z2, int rgba) {
		int a = rgba >>> 24 & 0xFF;
		int r = rgba >>> 16 & 0xFF;
		int g = rgba >>> 8 & 0xFF;
		int b = rgba & 0xFF;
		consumer.method_22918(matrix, (float) x1, (float) y1, (float) z1).method_22915(r, g, b, a).method_1344();
		consumer.method_22918(matrix, (float) x2, (float) y2, (float) z2).method_22915(r, g, b, a).method_1344();
	}
}
