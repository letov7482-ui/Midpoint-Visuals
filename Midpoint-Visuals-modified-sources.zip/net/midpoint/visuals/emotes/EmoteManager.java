package net.midpoint.visuals.emotes;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.midpoint.visuals.config.ConfigManager;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3675;

/**
 * Tracks the local player's active dance emote and exposes an
 * interpolated 0..360 degree spin angle that the {@code PlayerModelMixin}
 * layers on top of the vanilla body rotation via
 * {@link class_3532#method_16439(float, float, float)} against the render's tickDelta.
 *
 * @author Midpoint
 */
public final class EmoteManager {

	private static final class_304 SPIN_STAND = new class_304(
			"key.midpoint_visuals.emote_spin_stand",
			class_3675.class_307.field_1668,
			class_3675.field_32024,
			"category.midpoint_visuals");

	private static final class_304 SPIN_SIT = new class_304(
			"key.midpoint_visuals.emote_spin_sit",
			class_3675.class_307.field_1668,
			class_3675.field_32025,
			"category.midpoint_visuals");

	private static EmoteType activeEmote = EmoteType.NONE;
	private static int ticksElapsed = 0;
	private static float previousAngle = 0f;
	private static float currentAngle = 0f;

	private EmoteManager() {
	}

	public static void registerClient() {
		KeyBindingHelper.registerKeyBinding(SPIN_STAND);
		KeyBindingHelper.registerKeyBinding(SPIN_SIT);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (SPIN_STAND.method_1436()) {
				start(EmoteType.SPIN_STAND);
			}
			while (SPIN_SIT.method_1436()) {
				start(EmoteType.SPIN_SIT);
			}
			tick();
		});
	}

	private static void start(EmoteType type) {
		if (!ConfigManager.CONFIG.emotesEnabled) {
			return;
		}
		if (class_310.method_1551().field_1724 == null) {
			return;
		}
		activeEmote = type;
		ticksElapsed = 0;
		previousAngle = 0f;
		currentAngle = 0f;
	}

	private static void tick() {
		if (activeEmote == EmoteType.NONE) {
			return;
		}
		int duration = Math.max(1, ConfigManager.CONFIG.emoteSpinDurationTicks);
		ticksElapsed++;
		previousAngle = currentAngle;
		float progress = Math.min(1f, (float) ticksElapsed / duration);
		currentAngle = progress * 360f;

		if (ticksElapsed >= duration) {
			activeEmote = EmoteType.NONE;
			ticksElapsed = 0;
			previousAngle = 0f;
			currentAngle = 0f;
		}
	}

	public static EmoteType getActiveEmote() {
		return activeEmote;
	}

	public static boolean isSpinning() {
		return activeEmote == EmoteType.SPIN_STAND || activeEmote == EmoteType.SPIN_SIT;
	}

	public static boolean isSitting() {
		return activeEmote == EmoteType.SPIN_SIT;
	}

	/** Interpolated spin angle in degrees for the current render frame. */
	public static float getSpinAngleDegrees(float tickDelta) {
		return class_3532.method_16439(tickDelta, previousAngle, currentAngle);
	}
}
