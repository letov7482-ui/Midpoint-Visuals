package net.midpoint.visuals.mixin;

import net.midpoint.visuals.environment.EnvironmentModule;
import net.minecraft.class_4184;
import net.minecraft.class_758;
import net.minecraft.class_9958;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Overrides the vanilla fog colour after it has been computed, so this mod
 * still respects biome / potion fog blending and only tints the final
 * result. Reading the interpolated pulse via {@code EnvironmentModule}
 * keeps the tint frame-rate independent.
 *
 * <p>Since Minecraft 1.21.2, {@code FogRenderer#setupFog} takes the base
 * fog colour as a {@code Vector4f} parameter and returns an immutable
 * {@link class_9958} record instead of pushing the colour straight to
 * {@code RenderSystem}. This mixin therefore injects at {@code RETURN} and
 * substitutes a new {@code FogParameters} with the tinted colour, keeping
 * every other computed value (start/end/shape/alpha) untouched.</p>
 *
 * <p>NOTE: {@code FogRenderer#setupFog} is one of the vanilla methods most
 * likely to shift signature between 1.21.x patches as Mojang continues the
 * render-pipeline split; if this mixin fails to apply, paste the resulting
 * compiler error and it can be re-targeted quickly.</p>
 *
 * @author Midpoint
 */
@Mixin(class_758.class)
public class FogRendererMixin {

	@Inject(method = "setupFog", at = @At("RETURN"), cancellable = true)
	private static void midpointVisuals$tintFog(class_4184 camera, class_758.class_4596 fogMode, Vector4f color,
			float viewDistance, boolean thickFog, float partialTick,
			CallbackInfoReturnable<class_9958> cir) {
		if (!EnvironmentModule.isActive()) {
			return;
		}

		class_9958 original = cir.getReturnValue();
		int tintColor = EnvironmentModule.getFogColor();
		float pulse = 0.6f + 0.4f * EnvironmentModule.getPulse(partialTick);
		float r = ((tintColor >> 16) & 0xFF) / 255f * pulse;
		float g = ((tintColor >> 8) & 0xFF) / 255f * pulse;
		float b = (tintColor & 0xFF) / 255f * pulse;

		cir.setReturnValue(new class_9958(
				original.comp_3009(),
				original.comp_3010(),
				original.comp_3011(),
				r, g, b,
				original.comp_3015()));
	}
}
