package net.midpoint.visuals.mixin;

import net.midpoint.visuals.emotes.EmoteManager;
import net.minecraft.class_4184;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Adds a small, purely cosmetic FOV "kick" while a spin emote plays. This
 * only touches {@link class_757#method_3196}, a value read (not mutated) by
 * Sodium's own camera setup, so it stays compatible without needing to
 * touch any vertex/shader pipeline code Sodium replaces.
 *
 * @author Midpoint
 */
@Mixin(class_757.class)
public abstract class GameRendererMixin {

	@Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
	private void midpointVisuals$emoteFovKick(class_4184 camera, float partialTick, boolean useFovSetting,
			CallbackInfoReturnable<Float> cir) {
		if (!EmoteManager.isSpinning()) {
			return;
		}
		float progress = EmoteManager.getSpinAngleDegrees(partialTick) / 360.0f;
		float kick = (float) (Math.sin(progress * Math.PI) * 4.0);
		cir.setReturnValue(cir.getReturnValue() + kick);
	}
}
