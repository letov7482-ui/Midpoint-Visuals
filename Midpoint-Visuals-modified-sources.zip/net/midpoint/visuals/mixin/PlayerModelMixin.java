package net.midpoint.visuals.mixin;

import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.emotes.EmoteManager;
import net.minecraft.class_10055;
import net.minecraft.class_3532;
import net.minecraft.class_572;
import net.minecraft.class_591;
import net.minecraft.class_630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Layers the emote spin rotation on top of vanilla pose calculation. Runs
 * strictly after {@code super.setupAnim} so it overrides, rather than
 * fights with, the vanilla walk/swim/idle animation for the duration of
 * the emote.
 *
 * @author Midpoint
 */
@Mixin(class_591.class)
public abstract class PlayerModelMixin extends class_572<class_10055> {

	public PlayerModelMixin(class_630 root) {
		super(root);
	}

	@Inject(method = "setupAnim", at = @At("TAIL"))
	private void midpointVisuals$applyEmote(class_10055 state, CallbackInfo ci) {
		if (!ConfigManager.CONFIG.emotesEnabled || !EmoteManager.isSpinning()) {
			return;
		}

		// The render state already carries this frame's interpolated tick,
		// so a full-strength (1.0) sample of the emote's own internal
		// tick/tick-delta buffer gives a smooth per-frame angle here.
		float angleRad = class_3532.field_29844 * 2.0f * (EmoteManager.getSpinAngleDegrees(1.0f) / 360.0f);

		this.field_3391.field_3675 = angleRad;
		this.field_3398.field_3675 = angleRad;
		this.field_3394.field_3675 = angleRad;
		this.field_3401.field_3675 = angleRad;
		this.field_27433.field_3675 = angleRad;
		this.field_3392.field_3675 = angleRad;
		this.field_3397.field_3675 = angleRad;

		if (EmoteManager.isSitting()) {
			float bendRad = -class_3532.field_29845;
			this.field_3392.field_3654 = bendRad;
			this.field_3397.field_3654 = bendRad;
			this.field_3392.field_3655 = 2.0f;
			this.field_3397.field_3655 = 2.0f;
			this.field_3391.field_3656 += 6.0f;
			this.field_3398.field_3656 += 6.0f;
			this.field_3394.field_3656 += 6.0f;
			this.field_3401.field_3656 += 6.0f;
			this.field_27433.field_3656 += 6.0f;
		}
	}
}
