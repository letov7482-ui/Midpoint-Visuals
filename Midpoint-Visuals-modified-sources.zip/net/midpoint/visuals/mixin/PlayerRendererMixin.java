package net.midpoint.visuals.mixin;

import net.midpoint.visuals.cosmetics.HatFeatureRenderer;
import net.midpoint.visuals.cosmetics.HatLayers;
import net.midpoint.visuals.cosmetics.HatModel;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_5617;
import net.minecraft.class_591;
import net.minecraft.class_742;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Injects the {@link HatFeatureRenderer} into every player renderer instance.
 *
 * @author Midpoint
 */
@Mixin(class_1007.class)
public abstract class PlayerRendererMixin
		extends class_922<class_742, class_10055, class_591> {

	public PlayerRendererMixin(class_5617.class_5618 context, class_591 model, float shadowRadius) {
		super(context, model, shadowRadius);
	}

	@Inject(method = "<init>", at = @At("TAIL"))
	private void midpointVisuals$addHatLayer(class_5617.class_5618 context, boolean slim, CallbackInfo ci) {
		HatModel topHat = new HatModel(context.method_32167(HatLayers.TOP_HAT));
		HatModel fedora = new HatModel(context.method_32167(HatLayers.FEDORA));
		HatModel crown = new HatModel(context.method_32167(HatLayers.CROWN));
		HatModel wizard = new HatModel(context.method_32167(HatLayers.WIZARD));
		HatModel cowboy = new HatModel(context.method_32167(HatLayers.COWBOY));
		this.method_4046(new HatFeatureRenderer(this, topHat, fedora, crown, wizard, cowboy));
	}
}
