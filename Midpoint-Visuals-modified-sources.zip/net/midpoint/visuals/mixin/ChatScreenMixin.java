package net.midpoint.visuals.mixin;

import net.midpoint.visuals.hud.HudDragManager;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Lets the HUD be dragged directly from the chat screen.
 *
 * @author Midpoint
 */
@Mixin(class_408.class)
public abstract class ChatScreenMixin {

	@Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
	private void midpointVisuals$mouseClicked(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
		if (button == 0 && HudDragManager.beginDrag(mouseX, mouseY)) {
			cir.setReturnValue(true);
		}
	}

	@Inject(method = "mouseDragged", at = @At("HEAD"), cancellable = true)
	private void midpointVisuals$mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY,
			CallbackInfoReturnable<Boolean> cir) {
		if (button == 0 && HudDragManager.drag(mouseX, mouseY, thisScreenWidth(), thisScreenHeight())) {
			cir.setReturnValue(true);
		}
	}

	@Inject(method = "mouseReleased", at = @At("HEAD"), cancellable = true)
	private void midpointVisuals$mouseReleased(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
		if (button == 0 && HudDragManager.endDrag()) {
			cir.setReturnValue(true);
		}
	}

	private int thisScreenWidth() {
		return ((net.minecraft.class_437) (Object) this).field_22789;
	}

	private int thisScreenHeight() {
		return ((net.minecraft.class_437) (Object) this).field_22785;
	}
}
