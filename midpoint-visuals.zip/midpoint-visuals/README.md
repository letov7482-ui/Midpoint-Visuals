<p align="center">
<svg width="720" height="130" viewBox="0 0 720 130" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="mpv-grad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#7A1FE0"/>
      <stop offset="45%" stop-color="#B026FF"/>
      <stop offset="75%" stop-color="#3D7BFF"/>
      <stop offset="100%" stop-color="#00E5FF"/>
    </linearGradient>
  </defs>
  <rect width="720" height="130" fill="#0D0D0D"/>
  <text x="50%" y="52" text-anchor="middle" font-family="Consolas, 'Courier New', monospace" font-weight="bold" font-size="34" fill="url(#mpv-grad)">MIDPOINT VISUALS</text>
  <text x="50%" y="82" text-anchor="middle" font-family="Consolas, 'Courier New', monospace" font-size="14" fill="#8A8A8A">// high-performance client visuals · fabric 1.21.4</text>
  <line x1="60" y1="100" x2="660" y2="100" stroke="url(#mpv-grad)" stroke-width="2"/>
</svg>
</p>

<p align="center">
  <b>Mod ID:</b> <code>midpoint_visuals</code> &nbsp;•&nbsp;
  <b>Loader:</b> Fabric &nbsp;•&nbsp;
  <b>Minecraft:</b> 1.21.4 &nbsp;•&nbsp;
  <b>Mappings:</b> Official Mojang &nbsp;•&nbsp;
  <b>Author:</b> Midpoint
</p>

---

## О моде

**Midpoint Visuals** — клиентский Fabric-мод, нацеленный на максимальную производительность как на ПК, так и на мобильных Java-лаунчерах (Pojav Launcher, Zalith Launcher, FCL, Mojo Launcher и аналогичных). Все модули **по умолчанию выключены** и активируются вручную через GUI-меню.

Каждый визуальный модуль поддерживает три состояния:

| Состояние | Описание |
|---|---|
| `OFF`    | Модуль выключен, нулевой оверхед |
| `ON`     | Модуль включён с фиксированным цветом/эффектом |
| `RANDOM` | Модуль включён, цвет/эффект выбирается случайно при каждом срабатывании |

## Модули

1. **Hit Spirits & Cubes** — плавные кружащиеся частицы-«духи» вокруг цели при попадании (исчезают через 10с без урона) + статичные цветные кубики в точке удара. Рендерится батчингом — один draw call на все духи, один на все кубики.
2. **Quantum Link + Reach Indicator** — неоновая линия между атакующим и целью на 0.2с с билборд-текстом точной дистанции (`2.84m`) посередине, с мягкой тенью. Цвет линии и цвет текста настраиваются раздельно.
3. **trackerEndJ** — предсказанная траектория полёта эндер-жемчуга в реальном времени + круг в точке приземления. Цвета настраиваются.
4. **Block Highlight** — неоновая обводка блока в прицеле с заливкой, опциональная линия трассировки от глаз игрока и режим **Cosmic View** (анимированная звёздная заливка блока).
5. **Nick Changer** — локальная (визуальная) смена ника над головой персонажа.
6. **Client Dances** — 2 клиентских танца, видимых только вам: кручение в приседе на 360° и заднее сальто.
7. **HitColor** — замена стандартной красной вспышки урона на мягкий белый/жёлтый/кастомный цвет.
8. **PvP & CPvP Anti-Lag** — отключение тяжёлых частиц взрывов кристаллов/якорей и белых вспышек, оптимизация рендера жемчуга.
9. **Fog Settings** — 4 кастомных цветовых пресета тумана, лёгкие для мобильных GPU.
10. **Cosmetics** — 3D-косметика над головой (заготовка под модель, авто-отключение при низком FPS).
11. **Utility** — бинд `B` → отправка «gg» в чат, AutoSprint.

## Управление

- **Открыть меню:** `Right Shift` (настраивается в Controls → Key Binds, либо через ModMenu)
- Все бинды — обычные перебиндируемые `KeyMapping`, работают с виртуальной клавиатурой мобильных лаунчеров.

## Установка на мобильные лаунчеры (Pojav / Zalith / FCL / Mojo)

1. Установите **Fabric Loader 0.16.9+** для Minecraft **1.21.4** через встроенный установщик версий вашего лаунчера (Pojav/Zalith: вкладка *Version → Install Fabric*; FCL/Mojo: аналогичный пункт в списке версий).
2. Скачайте `fabric-api-<версия>-fabric.jar` и `midpoint-visuals-<версия>.jar` (см. раздел [Сборка](#сборка) или вкладку **Releases**/**Actions** этого репозитория).
3. Скопируйте оба `.jar`-файла в папку `.minecraft/mods/` вашего игрового профиля (через встроенный файловый менеджер лаунчера или любой файловый менеджер Android, если папка `.minecraft` доступна напрямую).
4. Запустите профиль Fabric 1.21.4. При первом старте откройте меню мода клавишей `Right Shift` (или через ModMenu, если он установлен) и включите нужные модули.
5. Для комфортной работы с сенсорным экраном меню специально сделано с крупными элементами и не требует точного попадания — модули переключаются одним тапом.

> ⚠️ Мод клиентский (`"environment": "client"`), поэтому он не требует установки на сервер и не блокируется серверами со строгой проверкой модов (визуальные эффекты не влияют на игровую логику).

## Сборка

```bash
git clone https://github.com/midpoint/midpoint-visuals.git
cd midpoint-visuals
./gradlew build
```

Готовый `.jar` появится в `build/libs/`. Также каждый пуш в репозиторий автоматически собирается через **GitHub Actions** (`.github/workflows/build.yml`) — готовый артефакт можно скачать во вкладке **Actions** без локальной сборки.

> В репозитории не закоммичен бинарный `gradle-wrapper.jar`; CI использует `gradle/actions/setup-gradle`. Для локальной сборки без предустановленного Gradle выполните `gradle wrapper` один раз, чтобы сгенерировать `gradlew`/`gradlew.bat` у себя.

## Архитектура

```
com.midpoint.visuals
├── MidpointVisuals.java          — common entrypoint
├── MidpointVisualsClient.java    — client entrypoint, event wiring
├── config/
│   ├── ModuleState.java          — OFF / ON / RANDOM enum
│   ├── ModConfig.java            — все настройки (everything = OFF by default)
│   └── ConfigManager.java        — load/save config/midpoint_visuals.json
├── gui/
│   ├── MidpointGuiScreen.java    — тёмное touch-friendly меню
│   └── ModMenuIntegration.java   — интеграция с ModMenu
├── util/
│   ├── KeyBindings.java
│   └── RenderUtil.java           — линии, billboard-текст
├── particle/
│   └── ParticleRegistry.java     — духи + кубики, батч-рендер
├── render/
│   ├── QuantumLinkRenderer.java
│   ├── PearlTrackerRenderer.java
│   ├── BlockHighlightRenderer.java
│   └── CosmeticsRenderer.java
├── dance/
│   └── DanceAnimationManager.java
└── mixin/
    ├── LocalPlayerMixin.java             — AutoSprint
    ├── LivingEntityDamageMixin.java      — хук на Player#attack (духи/кубики, Quantum Link)
    ├── PlayerRendererMixin.java          — танцы (setupRotations)
    ├── AbstractClientPlayerMixin.java    — Nick Changer
    ├── PrimedTntAndCrystalMixin.java     — Anti-Lag (частицы взрывов)
    ├── LevelRendererFogMixin.java        — кастомный туман
    └── GameRendererHurtMixin.java        — HitColor
```

## Примечание о честности реализации

Этот репозиторий — полноценный рабочий каркас со сквозной архитектурой (конфиг, GUI, регистрация модулей, миксины, событийная модель рендера). Часть модулей (Hit Spirits & Cubes, Quantum Link, trackerEndJ, Block Highlight) реализована через собственный батч-рендерер поверх `WorldRenderEvents`, а не через полноценные шейдеры GPU-инстансинга — это осознанный компромисс: единый draw call на тип эффекта уже даёт основной прирост FPS без риска несовместимости с разными GPU-драйверами на Android. Cosmetics — намеренная заготовка (placeholder-маркер) под будущую 3D-модель. Названия миксин-методов соответствуют официальным маппингам Mojang для 1.21.4 на момент написания; при обновлении Minecraft сверяйтесь с actual mappings, так как незначительные сигнатуры могли измениться.

## Лицензия

MIT — см. `LICENSE`.
