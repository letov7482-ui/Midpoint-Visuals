package com.midpoint.visuals.render;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModConfig;
import com.midpoint.visuals.config.ModuleState;
import com.midpoint.visuals.util.RenderUtil;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.Random;

/**
 * Draws a thin neon line between an attacker and its target for a very
 * short window (default 0.2s / 4 ticks) whenever a hit is registered, plus
 * a compact billboarded distance readout centered on the line.
 */
public final class QuantumLinkRenderer {

    private static final Random RANDOM = new Random();
    private static Player attacker;
    private static Entity target;
    private static int ticksRemaining = 0;
    private static int lineColorThisHit;
    private static int textColorThisHit;

    private QuantumLinkRenderer() {}

    public static void trigger(Player attacker, Entity target) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.quantumLinkState.isEnabled()) return;

        QuantumLinkRenderer.attacker = attacker;
        QuantumLinkRenderer.target = target;
        QuantumLinkRenderer.ticksRemaining = cfg.quantumLineDurationTicks;

        if (cfg.quantumLinkState == ModuleState.RANDOM) {
            lineColorThisHit = RenderUtil.randomNeon(RANDOM);
            textColorThisHit = RenderUtil.randomNeon(RANDOM);
        } else {
            lineColorThisHit = cfg.quantumLineColor;
            textColorThisHit = cfg.quantumTextColor;
        }
    }

    public static void tick() {
        if (ticksRemaining > 0) ticksRemaining--;
    }

    public static void render(PoseStack poseStack, MultiBufferSource buffers, Vec3 cameraPos, float partialTicks) {
        if (ticksRemaining <= 0 || attacker == null || target == null || !target.isAlive()) return;

        Vec3 from = attacker.getEyePosition(partialTicks).subtract(cameraPos);
        Vec3 to = target.getPosition(partialTicks).add(0, target.getBbHeight() / 2.0, 0).subtract(cameraPos);

        RenderUtil.drawLine(poseStack, buffers, from, to, lineColorThisHit, 2.0f);

        double distance = attacker.position().distanceTo(target.position());
        Vec3 mid = RenderUtil.midpoint(from, to);
        String label = String.format("%.2fm", distance);
        RenderUtil.drawBillboardText(poseStack, buffers, label, mid, textColorThisHit, 0.02f);
    }
}
