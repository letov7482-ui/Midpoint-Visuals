package com.midpoint.visuals.config;

/**
 * Plain serializable data holder for every setting in the mod.
 * ABSOLUTELY EVERYTHING defaults to OFF / vanilla behaviour, as required.
 * Colors are stored as 0xAARRGGBB or 0xRRGGBB packed ints.
 */
public class ModConfig {

    // ---------------------------------------------------------------
    // 1. Hit Spirits & Cubes
    // ---------------------------------------------------------------
    public ModuleState hitSpiritsState = ModuleState.OFF;
    public int hitSpiritColor = 0xFFFFFFFF;
    public int hitCubeColor = 0xFFFF3B3B;
    public int hitSpiritLifetimeTicks = 200; // 10s
    public int maxHitParticlesPerEntity = 40; // hard cap for mobile perf

    // ---------------------------------------------------------------
    // 2. Quantum Link + Reach Indicator
    // ---------------------------------------------------------------
    public ModuleState quantumLinkState = ModuleState.OFF;
    public int quantumLineColor = 0xFF00E5FF; // supports 0xFF000000 (black) too
    public int quantumTextColor = 0xFFFFFFFF;
    public int quantumLineDurationTicks = 4; // ~0.2s at 20tps

    // ---------------------------------------------------------------
    // 3. trackerEndJ (Ender Pearl trajectory)
    // ---------------------------------------------------------------
    public ModuleState pearlTrackerState = ModuleState.OFF;
    public int pearlLineColor = 0xFF00FF88;
    public int pearlLandingCircleColor = 0xFF00FF00;

    // ---------------------------------------------------------------
    // 4. Block Highlight
    // ---------------------------------------------------------------
    public ModuleState blockHighlightState = ModuleState.OFF;
    public int blockOutlineColor = 0xFF00E5FF;
    public int blockFillColor = 0x3300E5FF;
    public boolean blockTraceEnabled = false;
    public int blockTraceColor = 0x66FFFFFF;
    public boolean cosmicViewEnabled = false;
    public int cosmicColorA = 0xFF1B0033;
    public int cosmicColorB = 0xFF4400AA;

    // ---------------------------------------------------------------
    // 5. Nick Changer
    // ---------------------------------------------------------------
    public boolean nickChangerEnabled = false;
    public String customNickname = "";

    // ---------------------------------------------------------------
    // 6. Client Dances
    // ---------------------------------------------------------------
    public boolean dancesEnabled = false; // master toggle, individual dances triggered via keybinds/GUI

    // ---------------------------------------------------------------
    // 7. HitColor
    // ---------------------------------------------------------------
    public ModuleState hitColorState = ModuleState.OFF;
    public int hitFlashColor = 0x66FFFFFF; // soft white default

    // ---------------------------------------------------------------
    // 8. PvP & CPvP Anti-Lag
    // ---------------------------------------------------------------
    public boolean antiLagFlashDisabled = false;
    public boolean antiLagCrystalParticlesDisabled = false;
    public boolean antiLagAnchorParticlesDisabled = false;
    public boolean pearlRenderOptimization = false;

    // ---------------------------------------------------------------
    // 9. Fog Settings
    // ---------------------------------------------------------------
    public boolean customFogEnabled = false;
    public int fogPresetIndex = 0; // 0=off palette index
    public float fogDensityMultiplier = 1.0f;

    // ---------------------------------------------------------------
    // 10. Cosmetics
    // ---------------------------------------------------------------
    public boolean cosmeticsEnabled = false;
    public String cosmeticModelId = "monkey_on_mountain";
    public boolean cosmeticsAutoDisableOnLowFps = true;
    public int cosmeticsFpsThreshold = 30;

    // ---------------------------------------------------------------
    // 11. Utility
    // ---------------------------------------------------------------
    public boolean utilityGgBindEnabled = false;
    public boolean autoSprintEnabled = false;

    // ---------------------------------------------------------------
    // GUI / Keybinds
    // ---------------------------------------------------------------
    public int menuKeyCode = 344; // GLFW_KEY_RIGHT_SHIFT
    public int ggKeyCode = 66;    // GLFW_KEY_B
    public int dance1KeyCode = 293; // unused F14 placeholder, rebindable in GUI
    public int dance2KeyCode = 294;
}
