package com.midpoint.visuals.render;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModConfig;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.phys.Vec3;

/**
 * Cosmetics module - scaffold for rendering a 3D cosmetic above a player's
 * head (default placeholder id: "monkey_on_mountain"). Currently renders a
 * lightweight neon marker as a stand-in; swap {@link #renderCosmetic} for a
 * real baked model (BakedModel / EntityModel) once art assets are ready.
 * Auto-disables itself (via {@code cosmeticsAutoDisableOnLowFps} handled in
 * {@code MidpointVisualsClient}) if FPS drops too low, so it never becomes
 * the reason a low-end mobile device struggles.
 */
public final class CosmeticsRenderer {

    private CosmeticsRenderer() {}

    public static void render(PoseStack poseStack, MultiBufferSource buffers, Vec3 cameraPos, float partialTicks) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.cosmeticsEnabled) return;

        AbstractClientPlayer player = Minecraft.getInstance().player;
        if (player == null) return;

        Vec3 headPos = player.getPosition(partialTicks).add(0, player.getBbHeight() + 0.35, 0).subtract(cameraPos);
        renderCosmetic(poseStack, buffers, headPos, cfg.cosmeticModelId);
    }

    private static void renderCosmetic(PoseStack poseStack, MultiBufferSource buffers, Vec3 pos, String modelId) {
        // TODO: replace with a real baked/entity model lookup keyed by modelId.
        // Placeholder: a tiny neon marker so the hook point is visibly wired up.
        com.midpoint.visuals.util.RenderUtil.drawBillboardText(poseStack, buffers, "\u2726", pos, 0xFFFFD500, 0.02f);
    }
}
