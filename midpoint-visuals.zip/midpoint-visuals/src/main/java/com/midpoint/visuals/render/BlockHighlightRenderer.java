package com.midpoint.visuals.render;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModConfig;
import com.midpoint.visuals.util.RenderUtil;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Replaces the vanilla block-breaking outline overlay with a neon outline,
 * an optional semi-transparent fill, an optional aim-trace line from the
 * player's eyes to the block, and an optional "Cosmic View" starfield fill
 * (an animated end-portal-like pattern) using the two configurable colors.
 */
public final class BlockHighlightRenderer {

    private BlockHighlightRenderer() {}

    public static void render(PoseStack poseStack, MultiBufferSource buffers, Vec3 cameraPos, float partialTicks) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.blockHighlightState.isEnabled()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.hitResult == null || mc.hitResult.getType() != HitResult.Type.BLOCK) return;

        BlockHitResult hit = (BlockHitResult) mc.hitResult;
        BlockPos target = hit.getBlockPos();
        if (mc.level.getBlockState(target).isAir()) return;

        AABB box = new AABB(target).move(-cameraPos.x, -cameraPos.y, -cameraPos.z);

        drawOutline(poseStack, buffers, box, cfg.blockOutlineColor);

        if (cfg.cosmicViewEnabled) {
            drawCosmicFill(poseStack, buffers, box, cfg.cosmicColorA, cfg.cosmicColorB, mc.level.getGameTime() + partialTicks);
        } else if ((cfg.blockFillColor >>> 24) != 0) {
            drawFill(poseStack, buffers, box, cfg.blockFillColor);
        }

        if (cfg.blockTraceEnabled) {
            Vec3 eyes = mc.player.getEyePosition(partialTicks).subtract(cameraPos);
            Vec3 center = box.getCenter();
            RenderUtil.drawLine(poseStack, buffers, eyes, center, cfg.blockTraceColor, 1.0f);
        }
    }

    private static void drawOutline(PoseStack poseStack, MultiBufferSource buffers, AABB box, int color) {
        Vec3[] c = corners(box);
        int[][] edges = {
                {0,1},{1,2},{2,3},{3,0}, // bottom
                {4,5},{5,6},{6,7},{7,4}, // top
                {0,4},{1,5},{2,6},{3,7}  // verticals
        };
        for (int[] e : edges) {
            RenderUtil.drawLine(poseStack, buffers, c[e[0]], c[e[1]], color, 2.0f);
        }
    }

    private static void drawFill(PoseStack poseStack, MultiBufferSource buffers, AABB box, int argb) {
        VertexConsumer buffer = buffers.getBuffer(RenderType.translucent());
        float a = ((argb >>> 24) & 0xFF) / 255f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        addBoxQuads(poseStack, buffer, box, r, g, b, a);
    }

    /**
     * Cosmic View: a slowly scrolling two-tone pattern approximating the
     * End Portal starfield, cheaply faked with a handful of animated
     * translucent quads rather than a real shader (kept dependency-free).
     */
    private static void drawCosmicFill(PoseStack poseStack, MultiBufferSource buffers, AABB box, int colorA, int colorB, double time) {
        VertexConsumer buffer = buffers.getBuffer(RenderType.translucent());
        float t = (float) (time * 0.02);
        float mix = (float) (0.5 + 0.5 * Math.sin(t));

        float ar = ((colorA >> 16) & 0xFF) / 255f, ag = ((colorA >> 8) & 0xFF) / 255f, ab = (colorA & 0xFF) / 255f;
        float br = ((colorB >> 16) & 0xFF) / 255f, bg = ((colorB >> 8) & 0xFF) / 255f, bb = (colorB & 0xFF) / 255f;

        float r = ar + (br - ar) * mix;
        float g = ag + (bg - ag) * mix;
        float b = ab + (bb - ab) * mix;
        float a = 0.55f;

        addBoxQuads(poseStack, buffer, box, r, g, b, a);
    }

    private static void addBoxQuads(PoseStack poseStack, VertexConsumer buffer, AABB box, float r, float g, float b, float a) {
        PoseStack.Pose pose = poseStack.last();
        Vec3[] c = corners(box);
        int[][] faces = {
                {0,1,2,3}, // bottom
                {4,5,6,7}, // top
                {0,1,5,4}, // side
                {1,2,6,5}, // side
                {2,3,7,6}, // side
                {3,0,4,7}  // side
        };
        for (int[] f : faces) {
            for (int idx : f) {
                Vec3 v = c[idx];
                buffer.addVertex(pose, (float) v.x, (float) v.y, (float) v.z).setColor(r, g, b, a);
            }
        }
    }

    private static Vec3[] corners(AABB box) {
        return new Vec3[]{
                new Vec3(box.minX, box.minY, box.minZ),
                new Vec3(box.maxX, box.minY, box.minZ),
                new Vec3(box.maxX, box.minY, box.maxZ),
                new Vec3(box.minX, box.minY, box.maxZ),
                new Vec3(box.minX, box.maxY, box.minZ),
                new Vec3(box.maxX, box.maxY, box.minZ),
                new Vec3(box.maxX, box.maxY, box.maxZ),
                new Vec3(box.minX, box.maxY, box.maxZ),
        };
    }
}
