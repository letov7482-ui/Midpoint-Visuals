package com.midpoint.visuals.gui;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Exposes the Midpoint Visuals config screen through ModMenu's mod list.
 * Declared as an optional "modmenu" entrypoint in fabric.mod.json, so the
 * mod works fine even if ModMenu is not installed (the menu keybind still
 * opens {@link MidpointGuiScreen} directly).
 */
public class ModMenuIntegration implements ModMenuApi {

    @Override
    public ConfigScreenFactory<?> getModConfigScreenFactory() {
        return MidpointGuiScreen::new;
    }
}
