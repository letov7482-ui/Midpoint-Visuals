package com.midpoint.visuals.gui;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModConfig;
import com.midpoint.visuals.config.ModuleState;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Midpoint Visuals config menu.
 *
 * Pure vanilla-widget GUI (no third-party rendering libs), styled with a
 * deep matte black background (#0D0D0D) and large touch-friendly rows so it
 * is comfortable to use with a finger on Pojav/Zalith/FCL/Mojo launchers.
 * Reachable from ModMenu or by pressing the configurable menu key
 * (default: Right Shift).
 */
public class MidpointGuiScreen extends Screen {

    private static final int BG_COLOR = 0xFF0D0D0D;
    private static final int ACCENT_ON = 0xFF00E5FF;
    private static final int ACCENT_RANDOM = 0xFFB000FF;
    private static final int ACCENT_OFF = 0xFF3A3A3A;
    private static final int ROW_HEIGHT = 26;
    private static final int ROW_WIDTH = 340;

    private final Screen parent;
    private int scroll = 0;
    private final List<Row> rows = new ArrayList<>();

    public MidpointGuiScreen(Screen parent) {
        super(Component.literal("Midpoint Visuals"));
        this.parent = parent;
    }

    private record Row(String label, Supplier<String> valueText, Runnable onClick) {}

    @Override
    protected void init() {
        rows.clear();
        ModConfig cfg = ConfigManager.get();

        addStateRow("Hit Spirits & Cubes", () -> cfg.hitSpiritsState, s -> cfg.hitSpiritsState = s);
        addStateRow("Quantum Link + Reach", () -> cfg.quantumLinkState, s -> cfg.quantumLinkState = s);
        addStateRow("trackerEndJ (Pearl Path)", () -> cfg.pearlTrackerState, s -> cfg.pearlTrackerState = s);
        addStateRow("Block Highlight", () -> cfg.blockHighlightState, s -> cfg.blockHighlightState = s);
        addBoolRow("  \u21B3 Trace Line", () -> cfg.blockTraceEnabled, v -> cfg.blockTraceEnabled = v);
        addBoolRow("  \u21B3 Cosmic View", () -> cfg.cosmicViewEnabled, v -> cfg.cosmicViewEnabled = v);
        addStateRow("HitColor", () -> cfg.hitColorState, s -> cfg.hitColorState = s);
        addBoolRow("Nick Changer", () -> cfg.nickChangerEnabled, v -> cfg.nickChangerEnabled = v);
        addBoolRow("Client Dances", () -> cfg.dancesEnabled, v -> cfg.dancesEnabled = v);
        addBoolRow("Anti-Lag: Disable Flash", () -> cfg.antiLagFlashDisabled, v -> cfg.antiLagFlashDisabled = v);
        addBoolRow("Anti-Lag: Crystal Particles", () -> cfg.antiLagCrystalParticlesDisabled, v -> cfg.antiLagCrystalParticlesDisabled = v);
        addBoolRow("Anti-Lag: Anchor Particles", () -> cfg.antiLagAnchorParticlesDisabled, v -> cfg.antiLagAnchorParticlesDisabled = v);
        addBoolRow("Anti-Lag: Pearl Net Optimization", () -> cfg.pearlRenderOptimization, v -> cfg.pearlRenderOptimization = v);
        addBoolRow("Custom Fog", () -> cfg.customFogEnabled, v -> cfg.customFogEnabled = v);
        addBoolRow("Cosmetics", () -> cfg.cosmeticsEnabled, v -> cfg.cosmeticsEnabled = v);
        addBoolRow("AutoSprint", () -> cfg.autoSprintEnabled, v -> cfg.autoSprintEnabled = v);
        addBoolRow("'gg' Bind (B)", () -> cfg.utilityGgBindEnabled, v -> cfg.utilityGgBindEnabled = v);

        int centerX = this.width / 2;
        int y = topOfList() + rows.size() * ROW_HEIGHT + 20;

        EditBox nickBox = new EditBox(this.font, centerX - ROW_WIDTH / 2, Math.min(y, this.height - 60), ROW_WIDTH, 20, Component.literal("Nickname"));
        nickBox.setMaxLength(24);
        nickBox.setValue(cfg.customNickname);
        nickBox.setResponder(value -> cfg.customNickname = value);
        this.addRenderableWidget(nickBox);

        this.addRenderableWidget(Button.builder(Component.literal("Save & Close"), b -> {
            ConfigManager.save();
            this.onClose();
        }).bounds(centerX - 100, this.height - 32, 200, 24).build());
    }

    private int topOfList() {
        return 40;
    }

    private void addStateRow(String label, Supplier<ModuleState> getter, Consumer<ModuleState> setter) {
        rows.add(new Row(label, () -> getter.get().name(), () -> setter.accept(getter.get().next())));
    }

    private void addBoolRow(String label, Supplier<Boolean> getter, Consumer<Boolean> setter) {
        rows.add(new Row(label, () -> getter.get() ? "ON" : "OFF", () -> setter.accept(!getter.get())));
    }

    @Override
    public void render(GuiGraphics gfx, int mouseX, int mouseY, float partialTick) {
        gfx.fill(0, 0, this.width, this.height, BG_COLOR);

        gfx.drawCenteredString(this.font, "MIDPOINT VISUALS", this.width / 2, 14, 0xFF00E5FF);

        int centerX = this.width / 2;
        int top = topOfList() - scroll;

        for (int i = 0; i < rows.size(); i++) {
            Row row = rows.get(i);
            int rowY = top + i * ROW_HEIGHT;
            if (rowY < topOfList() - ROW_HEIGHT || rowY > this.height - 80) continue;

            int x = centerX - ROW_WIDTH / 2;
            boolean hovered = mouseX >= x && mouseX <= x + ROW_WIDTH && mouseY >= rowY && mouseY <= rowY + ROW_HEIGHT - 4;

            int rowBg = hovered ? 0xFF1A1A1A : 0xFF141414;
            gfx.fill(x, rowY, x + ROW_WIDTH, rowY + ROW_HEIGHT - 4, rowBg);

            gfx.drawString(this.font, row.label(), x + 10, rowY + 8, 0xFFE0E0E0, false);

            String value = row.valueText().get();
            int valueColor = switch (value) {
                case "ON" -> ACCENT_ON;
                case "RANDOM" -> ACCENT_RANDOM;
                default -> ACCENT_OFF;
            };
            int valueWidth = this.font.width(value);
            gfx.fill(x + ROW_WIDTH - valueWidth - 24, rowY + 4, x + ROW_WIDTH - 8, rowY + ROW_HEIGHT - 8, valueColor & 0x33FFFFFF);
            gfx.drawString(this.font, value, x + ROW_WIDTH - valueWidth - 16, rowY + 8, valueColor, false);
        }

        super.render(gfx, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int centerX = this.width / 2;
        int top = topOfList() - scroll;
        for (int i = 0; i < rows.size(); i++) {
            int rowY = top + i * ROW_HEIGHT;
            int x = centerX - ROW_WIDTH / 2;
            if (mouseX >= x && mouseX <= x + ROW_WIDTH && mouseY >= rowY && mouseY <= rowY + ROW_HEIGHT - 4) {
                rows.get(i).onClick().run();
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int maxScroll = Math.max(0, rows.size() * ROW_HEIGHT - (this.height - 140));
        scroll = Math.max(0, Math.min(maxScroll, scroll - (int) (verticalAmount * ROW_HEIGHT)));
        return true;
    }

    @Override
    public void onClose() {
        ConfigManager.save();
        this.minecraft.setScreen(parent);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
