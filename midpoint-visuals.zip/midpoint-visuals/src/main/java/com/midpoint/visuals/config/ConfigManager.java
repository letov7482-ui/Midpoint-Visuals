package com.midpoint.visuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Central config access point for the whole mod. Every module reads its
 * settings from {@link #get()}. Kept intentionally simple / allocation free
 * on the hot path since it is read every frame by multiple renderers.
 */
public final class ConfigManager {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("midpoint_visuals.json");

    private static ModConfig CONFIG;

    private ConfigManager() {}

    public static ModConfig get() {
        if (CONFIG == null) {
            load();
        }
        return CONFIG;
    }

    public static void load() {
        if (Files.exists(CONFIG_PATH)) {
            try (Reader reader = Files.newBufferedReader(CONFIG_PATH, StandardCharsets.UTF_8)) {
                ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
                CONFIG = loaded != null ? loaded : new ModConfig();
            } catch (IOException e) {
                CONFIG = new ModConfig();
            }
        } else {
            CONFIG = new ModConfig();
            save();
        }
    }

    public static void save() {
        if (CONFIG == null) return;
        try {
            Files.createDirectories(CONFIG_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(CONFIG_PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(CONFIG, writer);
            }
        } catch (IOException e) {
            // Non-fatal: config simply won't persist this session.
        }
    }
}
