package com.midpoint.visuals.dance;

import com.midpoint.visuals.config.ConfigManager;

/**
 * Tracks the currently playing client-side-only dance animation and exposes
 * simple progress getters consumed by {@code PlayerRendererMixin} to bend
 * the local player's model. Purely visual, never touches actual movement/
 * physics, so it is 100% safe on any server (anti-cheat friendly).
 */
public final class DanceAnimationManager {

    public enum Dance { NONE, SPIN_CROUCH, BACKFLIP }

    private static Dance current = Dance.NONE;
    private static int ticks = 0;

    private static final int SPIN_CROUCH_DURATION = 20;  // 1s
    private static final int BACKFLIP_DURATION = 15;     // 0.75s

    private DanceAnimationManager() {}

    public static void startDance1() {
        if (!ConfigManager.get().dancesEnabled) return;
        current = Dance.SPIN_CROUCH;
        ticks = 0;
    }

    public static void startDance2() {
        if (!ConfigManager.get().dancesEnabled) return;
        current = Dance.BACKFLIP;
        ticks = 0;
    }

    public static void tick() {
        if (current == Dance.NONE) return;
        ticks++;
        int duration = current == Dance.SPIN_CROUCH ? SPIN_CROUCH_DURATION : BACKFLIP_DURATION;
        if (ticks >= duration) {
            current = Dance.NONE;
            ticks = 0;
        }
    }

    public static Dance current() {
        return current;
    }

    /** 0..1 progress through the active dance, for interpolation in the renderer mixin. */
    public static float progress(float partialTicks) {
        int duration = current == Dance.SPIN_CROUCH ? SPIN_CROUCH_DURATION : BACKFLIP_DURATION;
        if (duration == 0) return 0f;
        return Math.min(1f, (ticks + partialTicks) / duration);
    }

    /** Yaw rotation in degrees for the 360-spin dance. */
    public static float spinYawDegrees(float partialTicks) {
        return progress(partialTicks) * 360f;
    }

    /** Pitch rotation in degrees for the backflip (0 -> 360 around X axis). */
    public static float backflipPitchDegrees(float partialTicks) {
        return progress(partialTicks) * 360f;
    }
}
