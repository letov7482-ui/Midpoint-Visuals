package com.midpoint.visuals;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Midpoint Visuals is a purely client-side mod (environment = "client" in
 * fabric.mod.json). This common entrypoint exists only to satisfy the
 * "main" entrypoint contract expected by some launchers/tools; all real
 * logic lives in {@link MidpointVisualsClient}.
 */
public class MidpointVisuals implements ModInitializer {

    public static final String MOD_ID = "midpoint_visuals";
    public static final Logger LOGGER = LoggerFactory.getLogger("Midpoint Visuals");

    @Override
    public void onInitialize() {
        LOGGER.info("Midpoint Visuals - common init (client-only mod)");
    }
}
