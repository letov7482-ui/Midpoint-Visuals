package com.midpoint.visuals.mixin;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModConfig;
import com.midpoint.visuals.config.ModuleState;
import com.midpoint.visuals.particle.ParticleRegistry;
import com.midpoint.visuals.render.QuantumLinkRenderer;
import com.midpoint.visuals.util.RenderUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

/**
 * Hooks {@link Player#attack(Entity)}, which fires client-side the moment
 * the local player swings and lands a hit (before the server confirms it),
 * giving zero-input-delay visual feedback. Used to drive both the Hit
 * Spirits & Cubes module and the Quantum Link reach indicator.
 */
@Mixin(Player.class)
public abstract class LivingEntityDamageMixin {

    private static final Random RANDOM = new Random();

    @Inject(method = "attack", at = @At("HEAD"))
    private void midpointVisuals$onAttack(Entity target, CallbackInfo ci) {
        Player self = (Player) (Object) this;
        if (self != Minecraft.getInstance().player) return; // local player only
        if (!(target instanceof LivingEntity living)) return;

        ModConfig cfg = ConfigManager.get();

        if (cfg.hitSpiritsState.isEnabled()) {
            int spiritColor = cfg.hitSpiritsState == ModuleState.RANDOM ? RenderUtil.randomNeon(RANDOM) : cfg.hitSpiritColor;
            int cubeColor = cfg.hitSpiritsState == ModuleState.RANDOM ? RenderUtil.randomNeon(RANDOM) : cfg.hitCubeColor;
            Vec3 hitPos = living.position().add(0, living.getBbHeight() / 2.0, 0);
            ParticleRegistry.spawnHitEffect(living, hitPos, spiritColor, cubeColor, cfg.hitSpiritLifetimeTicks, cfg.maxHitParticlesPerEntity);
        }

        if (cfg.quantumLinkState.isEnabled()) {
            QuantumLinkRenderer.trigger(self, target);
        }
    }
}
