package com.midpoint.visuals.config;

/**
 * Every visual module in Midpoint Visuals supports exactly three states:
 *
 *  OFF    - module completely disabled, zero overhead (default for everything).
 *  ON     - module enabled with a fixed, user-configured color/effect.
 *  RANDOM - module enabled, but picks a random color/effect each time it triggers.
 */
public enum ModuleState {
    OFF,
    ON,
    RANDOM;

    public boolean isEnabled() {
        return this != OFF;
    }

    public ModuleState next() {
        return values()[(ordinal() + 1) % values().length];
    }

    public static ModuleState fromString(String s, ModuleState fallback) {
        if (s == null) return fallback;
        try {
            return ModuleState.valueOf(s.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return fallback;
        }
    }
}
