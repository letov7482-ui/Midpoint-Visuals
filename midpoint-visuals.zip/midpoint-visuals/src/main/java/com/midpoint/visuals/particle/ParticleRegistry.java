package com.midpoint.visuals.particle;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.random.RandomGenerator;

/**
 * Self-contained, allocation-light hit-effect system.
 *
 * Rather than registering real vanilla ParticleType/ParticleProvider objects
 * (which requires sprite atlases and JSON definitions and adds per-particle
 * object overhead through the vanilla particle engine), Midpoint Visuals
 * drives its "spirits" and "cubes" through this manager and renders the
 * whole batch with a single VertexConsumer per type per frame - one draw
 * call for all spirits, one for all cubes, regardless of how many are alive.
 * This is the extreme-performance path requested for mobile GPUs.
 */
public final class ParticleRegistry {

    private static final int SPIRIT_LIFETIME_TICKS_DEFAULT = 200; // 10s @ 20tps
    private static final List<Spirit> SPIRITS = new ArrayList<>();
    private static final List<Cube> CUBES = new ArrayList<>();

    private ParticleRegistry() {}

    // -----------------------------------------------------------------
    // Spawning
    // -----------------------------------------------------------------

    public static void spawnHitEffect(LivingEntity target, Vec3 hitPos, int spiritColor, int cubeColor, int lifetimeTicks, int maxPerEntity) {
        long entityId = target.getId();
        long alive = SPIRITS.stream().filter(s -> s.entityId == entityId).count();
        if (alive < maxPerEntity) {
            SPIRITS.add(new Spirit(entityId, target, spiritColor, lifetimeTicks));
        }
        CUBES.add(new Cube(hitPos, cubeColor));
    }

    // -----------------------------------------------------------------
    // Tick
    // -----------------------------------------------------------------

    public static void tick(RandomGenerator random) {
        SPIRITS.removeIf(s -> s.tick(random));
        CUBES.removeIf(Cube::tick);
    }

    // -----------------------------------------------------------------
    // Render - one draw call per type
    // -----------------------------------------------------------------

    public static void render(PoseStack poseStack, MultiBufferSource buffers, float partialTicks) {
        if (SPIRITS.isEmpty() && CUBES.isEmpty()) return;

        if (!SPIRITS.isEmpty()) {
            VertexConsumer spiritBuffer = buffers.getBuffer(RenderType.lightning()); // additive-friendly translucent quads
            for (Spirit s : SPIRITS) {
                s.render(poseStack, spiritBuffer, partialTicks);
            }
        }

        if (!CUBES.isEmpty()) {
            VertexConsumer cubeBuffer = buffers.getBuffer(RenderType.translucent());
            for (Cube c : CUBES) {
                c.render(poseStack, cubeBuffer);
            }
        }
    }

    public static void clear() {
        SPIRITS.clear();
        CUBES.clear();
    }

    // -----------------------------------------------------------------
    // Internal light-weight particle state
    // -----------------------------------------------------------------

    private static final class Spirit {
        final long entityId;
        final LivingEntity target;
        final int color;
        int age = 0;
        final int lifetime;
        double angle;
        final double radius;
        final double heightOffset;

        Spirit(long entityId, LivingEntity target, int color, int lifetime) {
            this.entityId = entityId;
            this.target = target;
            this.color = color;
            this.lifetime = lifetime <= 0 ? SPIRIT_LIFETIME_TICKS_DEFAULT : lifetime;
            this.angle = Math.random() * Math.PI * 2;
            this.radius = 0.6 + Math.random() * 0.4;
            this.heightOffset = Math.random() * target.getBbHeight();
        }

        /** @return true if this spirit should be removed */
        boolean tick(RandomGenerator random) {
            age++;
            angle += 0.12; // gentle orbit speed, cheap per-tick update only
            return age >= lifetime || !target.isAlive();
        }

        void render(PoseStack poseStack, VertexConsumer buffer, float partialTicks) {
            if (!target.isAlive()) return;
            Vec3 center = target.getPosition(partialTicks).add(0, heightOffset, 0);
            double x = center.x + Math.cos(angle) * radius;
            double z = center.z + Math.sin(angle) * radius;
            float fade = 1.0f - ((float) age / lifetime);
            drawBillboardQuad(poseStack, buffer, x, center.y, z, 0.12 + 0.03 * Math.sin(angle * 2), color, fade);
        }
    }

    private static final class Cube {
        final Vec3 pos;
        final int color;
        int age = 0;
        static final int LIFETIME = 60; // 3s static freeze then fade

        Cube(Vec3 pos, int color) {
            this.pos = pos;
            this.color = color;
        }

        boolean tick() {
            age++;
            return age >= LIFETIME;
        }

        void render(PoseStack poseStack, VertexConsumer buffer) {
            float fade = age < LIFETIME - 15 ? 1.0f : (LIFETIME - age) / 15.0f;
            drawStaticCube(poseStack, buffer, pos, 0.08f, color, fade);
        }
    }

    // -----------------------------------------------------------------
    // Minimal geometry helpers (kept tiny on purpose - mobile GPU budget)
    // -----------------------------------------------------------------

    private static void drawBillboardQuad(PoseStack poseStack, VertexConsumer buffer, double x, double y, double z, double size, int argb, float fade) {
        float a = (((argb >> 24) & 0xFF) / 255f) * fade;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        PoseStack.Pose pose = poseStack.last();

        buffer.addVertex(pose, (float) (x - size), (float) (y - size), (float) z).setColor(r, g, b, a);
        buffer.addVertex(pose, (float) (x + size), (float) (y - size), (float) z).setColor(r, g, b, a);
        buffer.addVertex(pose, (float) (x + size), (float) (y + size), (float) z).setColor(r, g, b, a);
        buffer.addVertex(pose, (float) (x - size), (float) (y + size), (float) z).setColor(r, g, b, a);
    }

    private static void drawStaticCube(PoseStack poseStack, VertexConsumer buffer, Vec3 pos, float size, int argb, float fade) {
        float a = (((argb >> 24) & 0xFF) / 255f) * fade;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        PoseStack.Pose pose = poseStack.last();
        float x = (float) pos.x, y = (float) pos.y, z = (float) pos.z;

        // Single quad billboard-ish cube face is enough visually and keeps this
        // to 1 quad instead of 6 faces per cube - big win at high spam counts.
        buffer.addVertex(pose, x - size, y - size, z).setColor(r, g, b, a);
        buffer.addVertex(pose, x + size, y - size, z).setColor(r, g, b, a);
        buffer.addVertex(pose, x + size, y + size, z).setColor(r, g, b, a);
        buffer.addVertex(pose, x - size, y + size, z).setColor(r, g, b, a);
    }
}
