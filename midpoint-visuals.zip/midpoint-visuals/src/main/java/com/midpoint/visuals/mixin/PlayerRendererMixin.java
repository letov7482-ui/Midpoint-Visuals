package com.midpoint.visuals.mixin;

import com.midpoint.visuals.dance.DanceAnimationManager;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Client Dances module.
 * Bends the local player's model transform during setupRotations - purely
 * a render-time transform, never touches actual entity position/physics,
 * so it is visible ONLY on this client (other clients don't run this mixin
 * and receive no extra packets) and is safe on any server.
 */
@Mixin(PlayerRenderer.class)
public abstract class PlayerRendererMixin {

    @Inject(
            method = "setupRotations(Lnet/minecraft/client/player/AbstractClientPlayer;Lcom/mojang/blaze3d/vertex/PoseStack;FFFF)V",
            at = @At("TAIL")
    )
    private void midpointVisuals$applyDance(AbstractClientPlayer player, PoseStack poseStack, float ageInTicks, float rotationYaw, float partialTicks, float scale, CallbackInfo ci) {
        if (player != Minecraft.getInstance().player) return; // self only

        DanceAnimationManager.Dance dance = DanceAnimationManager.current();
        if (dance == DanceAnimationManager.Dance.NONE) return;

        float progress = DanceAnimationManager.progress(partialTicks);

        switch (dance) {
            case SPIN_CROUCH -> {
                float spin = DanceAnimationManager.spinYawDegrees(partialTicks);
                poseStack.mulPose(new org.joml.Quaternionf().rotateY((float) Math.toRadians(spin)));
                // small hop while "sitting": sine bounce peaking mid-animation
                float hop = (float) Math.sin(progress * Math.PI) * 0.35f;
                poseStack.translate(0, -hop, 0);
            }
            case BACKFLIP -> {
                float pitch = DanceAnimationManager.backflipPitchDegrees(partialTicks);
                poseStack.translate(0, 0.9, 0);
                poseStack.mulPose(new org.joml.Quaternionf().rotateX((float) Math.toRadians(-pitch)));
                poseStack.translate(0, -0.9, 0);
            }
            default -> { /* no-op */ }
        }
    }
}
