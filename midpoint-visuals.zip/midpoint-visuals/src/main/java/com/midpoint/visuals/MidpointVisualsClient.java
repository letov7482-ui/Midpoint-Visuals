package com.midpoint.visuals;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModConfig;
import com.midpoint.visuals.dance.DanceAnimationManager;
import com.midpoint.visuals.gui.MidpointGuiScreen;
import com.midpoint.visuals.particle.ParticleRegistry;
import com.midpoint.visuals.render.BlockHighlightRenderer;
import com.midpoint.visuals.render.CosmeticsRenderer;
import com.midpoint.visuals.render.PearlTrackerRenderer;
import com.midpoint.visuals.render.QuantumLinkRenderer;
import com.midpoint.visuals.util.KeyBindings;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.Minecraft;

import java.util.Random;

public class MidpointVisualsClient implements ClientModInitializer {

    private static final Random RANDOM = new Random();
    private int fpsSamples = 0;
    private int lowFpsStreak = 0;

    @Override
    public void onInitializeClient() {
        ConfigManager.load();
        KeyBindings.register();

        // --------------------------------------------------------------
        // World rendering: hit spirits/cubes, quantum link, pearl tracker,
        // block highlight. All batched into as few draw calls as possible
        // and skipped entirely (near-zero overhead) when their module is
        // OFF, which is the default state for everything.
        // --------------------------------------------------------------
        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            var poseStack = context.matrixStack();
            var buffers = context.consumers();
            if (buffers == null) return;
            var cameraPos = context.camera().getPosition();
            float partialTicks = context.tickDelta();

            ParticleRegistry.render(poseStack, buffers, partialTicks);
            QuantumLinkRenderer.render(poseStack, buffers, cameraPos, partialTicks);
            PearlTrackerRenderer.render(poseStack, buffers, cameraPos, partialTicks);
            BlockHighlightRenderer.render(poseStack, buffers, cameraPos, partialTicks);
            CosmeticsRenderer.render(poseStack, buffers, cameraPos, partialTicks);
        });

        // --------------------------------------------------------------
        // Client tick: input handling + module ticking.
        // --------------------------------------------------------------
        ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);

        MidpointVisuals.LOGGER.info("Midpoint Visuals client initialized - all modules OFF by default");
    }

    private void onClientTick(Minecraft client) {
        ModConfig cfg = ConfigManager.get();

        // Menu key
        while (KeyBindings.openMenu.consumeClick()) {
            if (client.screen == null) {
                client.setScreen(new MidpointGuiScreen(null));
            }
        }

        // 'gg' utility bind
        while (KeyBindings.ggBind.consumeClick()) {
            if (cfg.utilityGgBindEnabled && client.player != null) {
                client.player.connection.sendChat("gg");
            }
        }

        // Dance keybinds
        while (KeyBindings.dance1.consumeClick()) {
            if (cfg.dancesEnabled) DanceAnimationManager.startDance1();
        }
        while (KeyBindings.dance2.consumeClick()) {
            if (cfg.dancesEnabled) DanceAnimationManager.startDance2();
        }

        if (client.player == null) {
            ParticleRegistry.clear();
            return;
        }

        ParticleRegistry.tick(RANDOM);
        QuantumLinkRenderer.tick();
        DanceAnimationManager.tick();

        // Cosmetics auto-disable on low FPS
        if (cfg.cosmeticsEnabled && cfg.cosmeticsAutoDisableOnLowFps) {
            monitorFps(client, cfg);
        }
    }

    private void monitorFps(Minecraft client, ModConfig cfg) {
        int fps = client.getFps();
        fpsSamples++;
        if (fpsSamples % 20 != 0) return; // sample once per second

        if (fps < cfg.cosmeticsFpsThreshold) {
            lowFpsStreak++;
            if (lowFpsStreak >= 3) {
                cfg.cosmeticsEnabled = false;
                MidpointVisuals.LOGGER.info("Midpoint Visuals: Cosmetics auto-disabled due to low FPS ({} < {})", fps, cfg.cosmeticsFpsThreshold);
            }
        } else {
            lowFpsStreak = 0;
        }
    }
}
