package com.midpoint.visuals.mixin;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Nick Changer module (purely local/visual, no server-side effect).
 *
 * Overrides the display name used for the local player's floating nametag
 * and any other UI element that queries {@code getDisplayName()} /
 * {@code getName()} on the entity object (e.g. the player list row for
 * clients that source it from the entity rather than the raw GameProfile).
 *
 * NOTE: this cannot retroactively rewrite chat messages already formatted
 * by the server, since server-sent chat components already bake the real
 * username in - that is expected, this module is a cosmetic overlay only.
 */
@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerMixin {

    @Inject(method = "getName", at = @At("HEAD"), cancellable = true)
    private void midpointVisuals$overrideName(CallbackInfoReturnable<Component> cir) {
        applyOverride(cir);
    }

    @Inject(method = "getDisplayName", at = @At("HEAD"), cancellable = true)
    private void midpointVisuals$overrideDisplayName(CallbackInfoReturnable<Component> cir) {
        applyOverride(cir);
    }

    private void applyOverride(CallbackInfoReturnable<Component> cir) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.nickChangerEnabled || cfg.customNickname == null || cfg.customNickname.isBlank()) return;

        AbstractClientPlayer self = (AbstractClientPlayer) (Object) this;
        if (self != Minecraft.getInstance().player) return; // self only, never renames other players

        MutableComponent nick = Component.literal(cfg.customNickname);
        cir.setReturnValue(nick);
    }
}
