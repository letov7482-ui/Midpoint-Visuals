package com.midpoint.visuals.mixin;

import com.midpoint.visuals.config.ConfigManager;
import net.minecraft.client.player.LocalPlayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Utility module: AutoSprint.
 * Automatically enables sprinting while the player moves forward, is not
 * sneaking, has enough hunger, and is not already sprinting - exactly what
 * a manual W+Ctrl-double-tap would do, just automated client-side.
 */
@Mixin(LocalPlayer.class)
public abstract class LocalPlayerMixin {

    @Inject(method = "aiStep", at = @At("TAIL"))
    private void midpointVisuals$autoSprint(CallbackInfo ci) {
        if (!ConfigManager.get().autoSprintEnabled) return;

        LocalPlayer self = (LocalPlayer) (Object) this;
        boolean movingForward = self.zza > 0.0F;
        boolean canSprint = !self.isSprinting() && !self.isCrouching() && !self.isUsingItem()
                && self.getFoodData().getFoodLevel() > 6
                && !self.isPassenger();

        if (movingForward && canSprint) {
            self.setSprinting(true);
        } else if (!movingForward && self.isSprinting()) {
            self.setSprinting(false);
        }
    }
}
