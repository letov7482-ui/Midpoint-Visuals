package com.midpoint.visuals.mixin;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModConfig;
import com.midpoint.visuals.config.ModuleState;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiGraphics;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

/**
 * HitColor module: draws a soft, configurable full-screen tint whenever the
 * local player is in its hurt-flash window, replacing the harsh vanilla red
 * with a gentler default (soft white) or a fully custom color/random neon.
 */
@Mixin(Gui.class)
public abstract class GameRendererHurtMixin {

    private static final Random RANDOM = new Random();

    @Inject(method = "render", at = @At("TAIL"))
    private void midpointVisuals$hitColorOverlay(GuiGraphics guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.hitColorState.isEnabled()) return;

        var player = Minecraft.getInstance().player;
        if (player == null || player.hurtTime <= 0) return;

        int color = cfg.hitColorState == ModuleState.RANDOM
                ? (0x40000000 | (RANDOM.nextInt(0xFFFFFF)))
                : cfg.hitFlashColor;

        float intensity = player.hurtTime / (float) Math.max(1, player.hurtDuration);
        int alpha = (int) (((color >>> 24) & 0xFF) * intensity);
        int tinted = (alpha << 24) | (color & 0xFFFFFF);

        int w = guiGraphics.guiWidth();
        int h = guiGraphics.guiHeight();
        guiGraphics.fill(0, 0, w, h, tinted);
    }
}
