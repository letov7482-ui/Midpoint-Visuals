package com.midpoint.visuals.render;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModConfig;
import com.midpoint.visuals.util.RenderUtil;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.projectile.ThrownEnderpearl;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * "trackerEndJ" module: renders the predicted flight path of every thrown
 * ender pearl currently loaded, plus a small circle at the predicted
 * landing spot. Physics constants mirror vanilla ThrownEnderpearl
 * (gravity 0.03/tick, drag 0.99/tick, no air resistance until block hit).
 */
public final class PearlTrackerRenderer {

    private static final double GRAVITY = 0.03;
    private static final double DRAG = 0.99;
    private static final int MAX_STEPS = 140;

    private PearlTrackerRenderer() {}

    public static void render(PoseStack poseStack, MultiBufferSource buffers, Vec3 cameraPos, float partialTicks) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.pearlTrackerState.isEnabled()) return;

        Level level = Minecraft.getInstance().level;
        if (level == null) return;

        for (var entity : level.entitiesForRendering()) {
            if (!(entity instanceof ThrownEnderpearl pearl)) continue;

            Vec3 pos = pearl.getPosition(partialTicks);
            Vec3 motion = pearl.getDeltaMovement();

            List<Vec3> points = new ArrayList<>(MAX_STEPS);
            points.add(pos);

            Vec3 simPos = pos;
            Vec3 simVel = motion;
            BlockHitResult landing = null;

            for (int i = 0; i < MAX_STEPS; i++) {
                Vec3 next = simPos.add(simVel);
                HitResult hit = level.clip(new ClipContext(simPos, next,
                        ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, pearl));
                if (hit.getType() == HitResult.Type.BLOCK) {
                    points.add(hit.getLocation());
                    landing = (BlockHitResult) hit;
                    break;
                }
                simVel = simVel.multiply(DRAG, DRAG, DRAG).subtract(0, GRAVITY, 0);
                simPos = next;
                points.add(simPos);
            }

            for (int i = 0; i + 1 < points.size(); i++) {
                Vec3 a = points.get(i).subtract(cameraPos);
                Vec3 b = points.get(i + 1).subtract(cameraPos);
                RenderUtil.drawLine(poseStack, buffers, a, b, cfg.pearlLineColor, 1.5f);
            }

            if (landing != null) {
                drawLandingCircle(poseStack, buffers, landing.getBlockPos(), cameraPos, cfg.pearlLandingCircleColor);
            }
        }
    }

    private static void drawLandingCircle(PoseStack poseStack, MultiBufferSource buffers, BlockPos pos, Vec3 cameraPos, int color) {
        double cx = pos.getX() + 0.5 - cameraPos.x;
        double cy = pos.getY() + 1.02 - cameraPos.y;
        double cz = pos.getZ() + 0.5 - cameraPos.z;
        int segments = 20;
        double radius = 0.4;

        Vec3 prev = null;
        for (int i = 0; i <= segments; i++) {
            double theta = (Math.PI * 2 * i) / segments;
            Vec3 point = new Vec3(cx + Math.cos(theta) * radius, cy, cz + Math.sin(theta) * radius);
            if (prev != null) {
                RenderUtil.drawLine(poseStack, buffers, prev, point, color, 1.5f);
            }
            prev = point;
        }
    }
}
