package com.midpoint.visuals.util;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

/**
 * Shared low-level render helpers used by QuantumLinkRenderer, PearlTrackerRenderer
 * and BlockHighlightRenderer. Everything here is designed to be called at most a
 * handful of times per frame (never per-particle) to stay cheap on mobile GPUs.
 */
public final class RenderUtil {

    private RenderUtil() {}

    /**
     * Draws a single neon world-space line between two points using
     * {@link RenderType#lineStrip()}. ARGB packed color, alpha respected.
     */
    public static void drawLine(PoseStack poseStack, MultiBufferSource buffers, Vec3 from, Vec3 to, int argb, float lineWidth) {
        RenderSystem.lineWidth(lineWidth);
        VertexConsumer consumer = buffers.getBuffer(RenderType.lines());
        PoseStack.Pose pose = poseStack.last();

        float a = ((argb >> 24) & 0xFF) / 255f;
        float r = ((argb >> 16) & 0xFF) / 255f;
        float g = ((argb >> 8) & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;
        if (a <= 0f) a = 1f; // treat 0x00RRGGBB as opaque unless explicitly ARGB with alpha channel set

        float nx = (float) (to.x - from.x);
        float ny = (float) (to.y - from.y);
        float nz = (float) (to.z - from.z);
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len > 1.0e-4f) {
            nx /= len; ny /= len; nz /= len;
        }

        consumer.addVertex(pose, (float) from.x, (float) from.y, (float) from.z)
                .setColor(r, g, b, a)
                .setNormal(pose, nx, ny, nz);
        consumer.addVertex(pose, (float) to.x, (float) to.y, (float) to.z)
                .setColor(r, g, b, a)
                .setNormal(pose, nx, ny, nz);
    }

    /**
     * Renders a small camera-facing ("billboard") string with a soft drop
     * shadow behind it, centered on the given world position. Used for the
     * Quantum Link distance readout.
     */
    public static void drawBillboardText(PoseStack poseStack, MultiBufferSource buffers, String text, Vec3 worldPos, int color, float scale) {
        Minecraft mc = Minecraft.getInstance();
        Font font = mc.font;
        int width = font.width(text);

        poseStack.pushPose();
        poseStack.translate(worldPos.x, worldPos.y, worldPos.z);

        Quaternionf cameraRot = mc.gameRenderer.getMainCamera().rotation();
        poseStack.mulPose(cameraRot);
        poseStack.scale(-scale, -scale, scale);

        Matrix4f matrix = poseStack.last().pose();

        // Soft shadow pass, offset slightly behind/below the main text.
        int shadowColor = (0x66 << 24) | 0x000000;
        font.drawInBatch(text, -width / 2f + 1, 1, shadowColor, false, matrix, buffers,
                Font.DisplayMode.SEE_THROUGH, 0, 0xF000000);

        font.drawInBatch(text, -width / 2f, 0, color, false, matrix, buffers,
                Font.DisplayMode.NORMAL, 0, 0xF000000);

        poseStack.popPose();
    }

    public static Vec3 midpoint(Vec3 a, Vec3 b) {
        return a.add(b).scale(0.5);
    }

    public static int randomNeon(java.util.random.RandomGenerator random) {
        int[] palette = {0xFF00E5FF, 0xFFB000FF, 0xFF00FF88, 0xFFFF3B7C, 0xFFFFD500};
        return palette[random.nextInt(palette.length)];
    }
}
