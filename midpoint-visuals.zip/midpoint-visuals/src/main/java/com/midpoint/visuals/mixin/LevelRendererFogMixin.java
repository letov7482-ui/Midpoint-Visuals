package com.midpoint.visuals.mixin;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.ModConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.renderer.FogRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Fog Settings module: swaps the vanilla fog color for one of a handful of
 * lightweight color presets. Deliberately avoids touching fog density /
 * render-distance shaders (which are expensive on mobile Adreno/Mali GPUs)
 * and only recolors the existing fog, which is effectively free.
 */
@Mixin(FogRenderer.class)
public abstract class LevelRendererFogMixin {

    private static final int[][] PRESETS = {
            {0x1A1A2E, 0x16213E}, // Preset 0: Midnight Blue
            {0x2B0B3F, 0x0F0326}, // Preset 1: Cosmic Purple
            {0x3A1414, 0x160505}, // Preset 2: Blood Haze
            {0x0D2B1E, 0x041008}, // Preset 3: Toxic Green
    };

    @Inject(method = "setupColor", at = @At("TAIL"))
    private static void midpointVisuals$applyCustomFog(CallbackInfo ci) {
        ModConfig cfg = ConfigManager.get();
        if (!cfg.customFogEnabled) return;

        int idx = Math.max(0, Math.min(PRESETS.length - 1, cfg.fogPresetIndex));
        int packed = PRESETS[idx][0];
        float r = ((packed >> 16) & 0xFF) / 255f;
        float g = ((packed >> 8) & 0xFF) / 255f;
        float b = (packed & 0xFF) / 255f;

        RenderSystem.setShaderFogColor(r, g, b);
    }
}
