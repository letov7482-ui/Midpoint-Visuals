package com.midpoint.visuals.mixin;

import com.midpoint.visuals.config.ConfigManager;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * PvP & CPvP Anti-Lag module.
 *
 * Crystal/Anchor PvP ("CPvP") spam is one of the heaviest client-side
 * load sources on mobile GPUs: dozens of simultaneous explosions each
 * spawning bright particle emitters. This mixin intercepts client-side
 * explosion handling and, when enabled, skips spawning the associated
 * particle burst entirely - the explosion still deals damage and plays
 * its sound (server-authoritative), only the expensive visual burst and
 * the bright "flash" particle are removed.
 */
@Mixin(ClientLevel.class)
public abstract class PrimedTntAndCrystalMixin {

    @Inject(
            method = "addParticle(Lnet/minecraft/core/particles/ParticleOptions;DDDDDD)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void midpointVisuals$stripExplosionParticles(ParticleOptions options, double x, double y, double z, double vx, double vy, double vz, CallbackInfo ci) {
        var cfg = ConfigManager.get();
        if (!cfg.antiLagCrystalParticlesDisabled && !cfg.antiLagAnchorParticlesDisabled && !cfg.antiLagFlashDisabled) return;

        String key = options.getType().toString();
        boolean isExplosionLike = key.contains("explosion") || key.contains("flash");
        if (isExplosionLike) {
            ci.cancel();
        }
    }

    // Reserved hook point for a future, more surgical distinction between
    // End Crystal explosions and Respawn Anchor explosions (both currently
    // share the same generic particle suppression above for simplicity and
    // maximum FPS gain on low-end mobile devices).
    @SuppressWarnings("unused")
    private static boolean midpointVisuals$isNearAnchor(Vec3 pos) {
        return false;
    }
}
