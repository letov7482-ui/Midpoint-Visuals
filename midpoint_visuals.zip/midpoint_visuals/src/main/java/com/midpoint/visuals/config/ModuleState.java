package com.midpoint.visuals.config;

/**
 * Every module in Midpoint Visuals can be OFF, ON (fixed configured color/style)
 * or RANDOM (color/style is re-rolled periodically at runtime).
 */
public enum ModuleState {
	OFF,
	ON,
	RANDOM;

	public ModuleState next() {
		return switch (this) {
			case OFF -> ON;
			case ON -> RANDOM;
			case RANDOM -> OFF;
		};
	}

	public boolean isActive() {
		return this != OFF;
	}

	public String displayName() {
		return switch (this) {
			case OFF -> "OFF";
			case ON -> "ON";
			case RANDOM -> "RANDOM";
		};
	}
}
