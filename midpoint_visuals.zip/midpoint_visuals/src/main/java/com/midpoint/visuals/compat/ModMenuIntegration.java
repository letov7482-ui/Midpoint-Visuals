package com.midpoint.visuals.compat;

import com.midpoint.visuals.gui.MidpointGuiScreen;
import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;

/**
 * Optional ModMenu entrypoint (declared under "modmenu" in fabric.mod.json).
 * If ModMenu isn't installed this class is simply never loaded/referenced.
 */
public class ModMenuIntegration implements ModMenuApi {

	@Override
	public ConfigScreenFactory<?> getModConfigScreenFactory() {
		return MidpointGuiScreen::new;
	}
}
