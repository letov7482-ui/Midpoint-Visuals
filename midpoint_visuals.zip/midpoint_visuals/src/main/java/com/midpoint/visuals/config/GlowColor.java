package com.midpoint.visuals.config;

/**
 * The fixed palette offered for the Item Glow module.
 * ARGB ints are used directly by GuiGraphics#fill.
 */
public enum GlowColor {
	PURPLE("Purple", 0x80A335E6),
	BLACK("Black", 0x90101014),
	YELLOW("Yellow", 0x80F5D442),
	BLUE("Blue", 0x803D8BFF);

	public final String label;
	public final int argb;

	GlowColor(String label, int argb) {
		this.label = label;
		this.argb = argb;
	}

	public GlowColor next() {
		GlowColor[] values = values();
		return values[(this.ordinal() + 1) % values.length];
	}
}
