package com.midpoint.visuals.gui;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.hud.InventoryHudOverlay;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Lets the player freely drag the Inventory HUD panel anywhere on screen
 * (including snapping into corners) with the mouse. Opened via the
 * "Edit HUD Position" button in MidpointGuiScreen.
 */
public class HudEditScreen extends Screen {

	private final Screen parent;
	private boolean dragging = false;
	private double dragOffsetX;
	private double dragOffsetY;

	public HudEditScreen(Screen parent) {
		super(Component.literal("Edit HUD Position"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		int buttonWidth = 140;
		this.addRenderableWidget(Button.builder(Component.literal("Snap Top-Left"), b -> snap(12, 12))
				.bounds(12, this.height - 40, buttonWidth, 24).build());
		this.addRenderableWidget(Button.builder(Component.literal("Snap Top-Right"), b ->
						snap(this.width - InventoryHudOverlay.PANEL_WIDTH - 12, 12))
				.bounds(12 + buttonWidth + 8, this.height - 40, buttonWidth, 24).build());
		this.addRenderableWidget(Button.builder(Component.literal("Snap Bottom-Left"), b ->
						snap(12, this.height - InventoryHudOverlay.PANEL_HEIGHT - 12))
				.bounds(12, this.height - 70, buttonWidth, 24).build());
		this.addRenderableWidget(Button.builder(Component.literal("Snap Bottom-Right"), b ->
						snap(this.width - InventoryHudOverlay.PANEL_WIDTH - 12,
								this.height - InventoryHudOverlay.PANEL_HEIGHT - 12))
				.bounds(12 + buttonWidth + 8, this.height - 70, buttonWidth, 24).build());

		this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
				.bounds(this.width - 100, 12, 88, 24).build());
	}

	private void snap(int x, int y) {
		ConfigManager.CONFIG.hudX = x;
		ConfigManager.CONFIG.hudY = y;
		ConfigManager.save();
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		graphics.fill(0, 0, this.width, this.height, 0xCC0D0D0D);
		graphics.drawCenteredString(this.font, "Drag the panel below to reposition it", this.width / 2, 12, 0xFF39FF6A);

		// Draw a live preview of the HUD panel at its current configured position.
		int x = ConfigManager.CONFIG.hudX;
		int y = ConfigManager.CONFIG.hudY;
		int w = InventoryHudOverlay.PANEL_WIDTH;
		int h = InventoryHudOverlay.PANEL_HEIGHT;

		graphics.fill(x, y, x + w, y + h, 0xC0161616);
		graphics.fill(x, y, x + w, y + 2, 0xFF39FF6A);
		graphics.drawCenteredString(this.font, "Midpoint Visuals", x + w / 2, y + h / 2 - 4, 0xFF39FF6A);

		super.render(graphics, mouseX, mouseY, partialTick);
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		if (button == 0 && isInsidePanel(mouseX, mouseY)) {
			dragging = true;
			dragOffsetX = mouseX - ConfigManager.CONFIG.hudX;
			dragOffsetY = mouseY - ConfigManager.CONFIG.hudY;
			return true;
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	@Override
	public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
		if (dragging) {
			int newX = (int) Math.round(mouseX - dragOffsetX);
			int newY = (int) Math.round(mouseY - dragOffsetY);

			newX = Math.max(0, Math.min(this.width - InventoryHudOverlay.PANEL_WIDTH, newX));
			newY = Math.max(0, Math.min(this.height - InventoryHudOverlay.PANEL_HEIGHT, newY));

			ConfigManager.CONFIG.hudX = newX;
			ConfigManager.CONFIG.hudY = newY;
			return true;
		}
		return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
	}

	@Override
	public boolean mouseReleased(double mouseX, double mouseY, int button) {
		if (button == 0 && dragging) {
			dragging = false;
			ConfigManager.save();
			return true;
		}
		return super.mouseReleased(mouseX, mouseY, button);
	}

	private boolean isInsidePanel(double mouseX, double mouseY) {
		int x = ConfigManager.CONFIG.hudX;
		int y = ConfigManager.CONFIG.hudY;
		int w = InventoryHudOverlay.PANEL_WIDTH;
		int h = InventoryHudOverlay.PANEL_HEIGHT;
		return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
	}

	@Override
	public void onClose() {
		ConfigManager.save();
		this.minecraft.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
