package com.midpoint.visuals.mixin;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.GlowColor;
import com.midpoint.visuals.config.MidpointConfig;
import com.midpoint.visuals.config.ModuleState;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

/**
 * Draws a soft colored overlay on top of any occupied slot in every
 * inventory-style screen (survival inventory, chests, crafting tables, etc).
 * Purely cosmetic - does not alter tooltips, item data or click behaviour.
 */
@Mixin(AbstractContainerScreen.class)
public abstract class AbstractContainerScreenMixin {

	@Unique
	private static final Random midpointVisuals$random = new Random();
	@Unique
	private static int midpointVisuals$cachedColor = GlowColor.PURPLE.argb;
	@Unique
	private static long midpointVisuals$lastRoll = 0L;

	@Inject(method = "renderSlot", at = @At("TAIL"))
	private void midpointVisuals$onRenderSlot(GuiGraphics guiGraphics, Slot slot, CallbackInfo ci) {
		MidpointConfig cfg = ConfigManager.CONFIG;
		if (!cfg.itemGlowState.isActive() || !slot.hasItem()) {
			return;
		}

		int color;
		if (cfg.itemGlowState == ModuleState.RANDOM) {
			long now = System.currentTimeMillis();
			if (now - midpointVisuals$lastRoll > 5000L) {
				GlowColor[] palette = GlowColor.values();
				midpointVisuals$cachedColor = palette[midpointVisuals$random.nextInt(palette.length)].argb;
				midpointVisuals$lastRoll = now;
			}
			color = midpointVisuals$cachedColor;
		} else {
			color = cfg.itemGlowColor.argb;
		}

		guiGraphics.fill(slot.x, slot.y, slot.x + 16, slot.y + 16, color);
	}
}
