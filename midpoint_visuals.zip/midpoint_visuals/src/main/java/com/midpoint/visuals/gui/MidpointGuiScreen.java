package com.midpoint.visuals.gui;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.GlowColor;
import com.midpoint.visuals.config.HighlightStyle;
import com.midpoint.visuals.config.MidpointConfig;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Deep matte black (#0D0D0D) settings screen for Midpoint Visuals.
 * Large, touch-friendly buttons - works well on PC and on mobile Minecraft
 * clients (Pojav / Zalith / Mojo / FCL) where precise clicking is harder.
 */
public class MidpointGuiScreen extends Screen {

	private static final int BG_COLOR = 0xFF0D0D0D;
	private static final int PANEL_COLOR = 0xFF161616;
	private static final int ACCENT_COLOR = 0xFF39FF6A;

	private final Screen parent;

	public MidpointGuiScreen(Screen parent) {
		super(Component.literal("Midpoint Visuals"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		MidpointConfig cfg = ConfigManager.CONFIG;

		int centerX = this.width / 2;
		int buttonWidth = Math.min(340, this.width - 40);
		int buttonHeight = 36;
		int spacing = 10;
		int startY = 46;

		int y = startY;

		// --- BlockHighlight ---
		y = addStateButton(centerX, y, buttonWidth, buttonHeight,
				"Block Highlight", () -> cfg.blockHighlightState.displayName(),
				() -> {
					cfg.blockHighlightState = cfg.blockHighlightState.next();
					ConfigManager.save();
				});

		y = addCycleButton(centerX, y, buttonWidth, buttonHeight,
				"Highlight Style", () -> cfg.blockHighlightStyle.label,
				() -> {
					cfg.blockHighlightStyle = cfg.blockHighlightStyle.next();
					ConfigManager.save();
				});

		y = addColorCycleButton(centerX, y, buttonWidth, buttonHeight, "Highlight Color",
				() -> cfg.blockHighlightColor,
				color -> {
					cfg.blockHighlightColor = color;
					ConfigManager.save();
				});

		y += spacing;

		// --- Inventory HUD ---
		y = addStateButton(centerX, y, buttonWidth, buttonHeight,
				"Inventory HUD", () -> cfg.inventoryHudState.displayName(),
				() -> {
					cfg.inventoryHudState = cfg.inventoryHudState.next();
					ConfigManager.save();
				});

		this.addRenderableWidget(Button.builder(Component.literal("Edit HUD Position"), b -> {
					this.minecraft.setScreen(new HudEditScreen(this));
				})
				.bounds(centerX - buttonWidth / 2, y, buttonWidth, buttonHeight)
				.build());
		y += buttonHeight + spacing;

		// --- Item Glow ---
		y = addStateButton(centerX, y, buttonWidth, buttonHeight,
				"Item Glow", () -> cfg.itemGlowState.displayName(),
				() -> {
					cfg.itemGlowState = cfg.itemGlowState.next();
					ConfigManager.save();
				});

		y = addCycleButton(centerX, y, buttonWidth, buttonHeight,
				"Glow Color", () -> cfg.itemGlowColor.label,
				() -> {
					cfg.itemGlowColor = cfg.itemGlowColor.next();
					ConfigManager.save();
				});

		y += spacing + 4;

		this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
				.bounds(centerX - buttonWidth / 2, y, buttonWidth, buttonHeight)
				.build());
	}

	private int addStateButton(int centerX, int y, int w, int h, String label,
			java.util.function.Supplier<String> stateSupplier, Runnable onPress) {
		Button button = Button.builder(
						Component.literal(label + ": " + stateSupplier.get()),
						b -> {
							onPress.run();
							b.setMessage(Component.literal(label + ": " + stateSupplier.get()));
						})
				.bounds(centerX - w / 2, y, w, h)
				.build();
		this.addRenderableWidget(button);
		return y + h + 10;
	}

	private int addCycleButton(int centerX, int y, int w, int h, String label,
			java.util.function.Supplier<String> valueSupplier, Runnable onPress) {
		Button button = Button.builder(
						Component.literal(label + ": " + valueSupplier.get()),
						b -> {
							onPress.run();
							b.setMessage(Component.literal(label + ": " + valueSupplier.get()));
						})
				.bounds(centerX - w / 2, y, w, h)
				.build();
		this.addRenderableWidget(button);
		return y + h + 10;
	}

	private int addColorCycleButton(int centerX, int y, int w, int h, String label,
			java.util.function.Supplier<Integer> colorSupplier,
			java.util.function.IntConsumer onPick) {
		// Simple preset palette cycle, including black, for the highlight color.
		int[] palette = {0xFF39FF6A, 0xFF3DAAFF, 0xFFFF3D5A, 0xFFF5D442, 0xFFA335E6, 0xFFFFFFFF, 0xFF000000};

		Button button = Button.builder(
						Component.literal(label),
						b -> {
							int current = colorSupplier.get();
							int idx = 0;
							for (int i = 0; i < palette.length; i++) {
								if (palette[i] == current) {
									idx = i;
									break;
								}
							}
							int next = palette[(idx + 1) % palette.length];
							onPick.accept(next);
						})
				.bounds(centerX - w / 2, y, w, h)
				.build();
		this.addRenderableWidget(button);
		return y + h + 10;
	}

	@Override
	public void render(net.minecraft.client.gui.GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		graphics.fill(0, 0, this.width, this.height, BG_COLOR);
		graphics.fill(20, 14, this.width - 20, 40, PANEL_COLOR);
		graphics.drawCenteredString(this.font, this.title, this.width / 2, 20, ACCENT_COLOR);

		super.render(graphics, mouseX, mouseY, partialTick);
	}

	@Override
	public void onClose() {
		ConfigManager.save();
		this.minecraft.setScreen(parent);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}
}
