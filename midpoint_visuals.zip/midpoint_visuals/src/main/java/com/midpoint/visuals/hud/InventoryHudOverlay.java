package com.midpoint.visuals.hud;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.config.MidpointConfig;
import com.midpoint.visuals.config.ModuleState;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

import java.util.Random;

/**
 * Renders the movable "Midpoint Visuals" inventory + armor durability panel.
 * Position (hudX / hudY) is edited live from HudEditScreen and persisted via
 * ConfigManager. Rendering itself is a handful of blit/text calls - cheap
 * enough to run every frame without batching concerns.
 */
public class InventoryHudOverlay implements LayeredDraw.Layer {

	private static final Random RANDOM = new Random();
	private static int cachedAccent = 0xFF39FF6A;
	private static long lastRoll = 0L;

	public static final int PANEL_WIDTH = 176;
	public static final int PANEL_HEIGHT = 96;

	@Override
	public void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
		MidpointConfig cfg = ConfigManager.CONFIG;
		if (!cfg.inventoryHudState.isActive()) {
			return;
		}

		Minecraft client = Minecraft.getInstance();
		if (client.player == null || client.options.hideGui) {
			return;
		}

		int x = cfg.hudX;
		int y = cfg.hudY;
		int accent = resolveAccent(cfg);

		// Background panel
		graphics.fill(x, y, x + PANEL_WIDTH, y + PANEL_HEIGHT, 0xB00D0D0D);
		graphics.fill(x, y, x + PANEL_WIDTH, y + 1, accent);
		graphics.fill(x, y + PANEL_HEIGHT - 1, x + PANEL_WIDTH, y + PANEL_HEIGHT, accent);
		graphics.fill(x, y, x + 1, y + PANEL_HEIGHT, accent);
		graphics.fill(x + PANEL_WIDTH - 1, y, x + PANEL_WIDTH, y + PANEL_HEIGHT, accent);

		graphics.drawString(client.font, Component.literal("Midpoint Visuals"), x + 6, y + 5, accent, false);

		// Hotbar (9 slots) as a compact icon row
		int slotSize = 18;
		int gridStartX = x + 6;
		int gridStartY = y + 18;
		for (int i = 0; i < 9; i++) {
			ItemStack stack = client.player.getInventory().getItem(i);
			int sx = gridStartX + i * slotSize;
			graphics.fill(sx, gridStartY, sx + 16, gridStartY + 16, 0x40FFFFFF);
			if (!stack.isEmpty()) {
				graphics.renderItem(stack, sx, gridStartY);
				graphics.renderItemDecorations(client.font, stack, sx, gridStartY);
			}
		}

		// Armor durability rows
		EquipmentSlot[] armorSlots = {
				EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
		};
		String[] labels = {"Helmet", "Chest", "Legs", "Boots"};

		int rowY = gridStartY + 22;
		for (int i = 0; i < armorSlots.length; i++) {
			ItemStack piece = client.player.getItemBySlot(armorSlots[i]);
			int ry = rowY + i * 12;

			graphics.drawString(client.font, Component.literal(labels[i]), x + 6, ry, 0xFFAAAAAA, false);

			int barX = x + 60;
			int barWidth = 96;
			graphics.fill(barX, ry + 1, barX + barWidth, ry + 5, 0xFF2A2A2A);

			if (!piece.isEmpty() && piece.isDamageableItem()) {
				int max = piece.getMaxDamage();
				int dmg = piece.getDamageValue();
				float ratio = Math.max(0f, Math.min(1f, 1f - ((float) dmg / (float) max)));
				int filled = (int) (barWidth * ratio);
				int barColor = ratio > 0.5f ? 0xFF55D65A : (ratio > 0.2f ? 0xFFE0C23A : 0xFFE0453A);
				graphics.fill(barX, ry + 1, barX + filled, ry + 5, barColor);
			} else if (!piece.isEmpty()) {
				graphics.fill(barX, ry + 1, barX + barWidth, ry + 5, accent);
			}
		}
	}

	private static int resolveAccent(MidpointConfig cfg) {
		if (cfg.inventoryHudState == ModuleState.RANDOM) {
			long now = System.currentTimeMillis();
			if (now - lastRoll > 4000L) {
				cachedAccent = 0xFF000000
						| (RANDOM.nextInt(256) << 16)
						| (RANDOM.nextInt(256) << 8)
						| RANDOM.nextInt(256);
				lastRoll = now;
			}
			return cachedAccent;
		}
		return cfg.hudAccentColor;
	}
}
