package com.midpoint.visuals;

import com.midpoint.visuals.config.ConfigManager;
import com.midpoint.visuals.gui.MidpointGuiScreen;
import com.midpoint.visuals.hud.InventoryHudOverlay;
import com.midpoint.visuals.render.BlockHighlightRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import org.lwjgl.glfw.GLFW;

public class MidpointVisualsClient implements ClientModInitializer {

	private static KeyMapping openGuiKey;

	@Override
	public void onInitializeClient() {
		ConfigManager.load();

		openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
				"key.midpoint_visuals.open_gui",
				GLFW.GLFW_KEY_RIGHT_SHIFT,
				"category.midpoint_visuals"
		));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (openGuiKey.consumeClick()) {
				if (client.screen == null) {
					client.setScreen(new MidpointGuiScreen(null));
				}
			}
		});

		WorldRenderEvents.AFTER_TRANSLUCENT.register(BlockHighlightRenderer::render);

		HudElementRegistry.addLast(
				ResourceLocation.fromNamespaceAndPath(MidpointVisuals.MOD_ID, "inventory_hud"),
				new InventoryHudOverlay()
		);

		MidpointVisuals.LOGGER.info("Midpoint Visuals initialized (client).");
	}

	/**
	 * Opens the mod's settings screen, used by ModMenu integration too.
	 */
	public static void openSettings(net.minecraft.client.gui.screens.Screen parent) {
		Minecraft.getInstance().setScreen(new MidpointGuiScreen(parent));
	}
}
