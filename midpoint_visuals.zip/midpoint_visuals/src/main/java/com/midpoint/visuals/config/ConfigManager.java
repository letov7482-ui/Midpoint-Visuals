package com.midpoint.visuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Loads and persists the mod configuration to
 * <gameDir>/config/midpoint_visuals.json
 */
public final class ConfigManager {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path CONFIG_PATH =
			FabricLoader.getInstance().getConfigDir().resolve("midpoint_visuals.json");

	public static MidpointConfig CONFIG = new MidpointConfig();

	private ConfigManager() {
	}

	public static void load() {
		if (!Files.exists(CONFIG_PATH)) {
			CONFIG = new MidpointConfig();
			save();
			return;
		}

		try (Reader reader = Files.newBufferedReader(CONFIG_PATH, StandardCharsets.UTF_8)) {
			MidpointConfig loaded = GSON.fromJson(reader, MidpointConfig.class);
			CONFIG = loaded != null ? loaded : new MidpointConfig();
		} catch (IOException e) {
			CONFIG = new MidpointConfig();
		}
	}

	public static void save() {
		try {
			Files.createDirectories(CONFIG_PATH.getParent());
			try (Writer writer = Files.newBufferedWriter(CONFIG_PATH, StandardCharsets.UTF_8)) {
				GSON.toJson(CONFIG, writer);
			}
		} catch (IOException ignored) {
			// Non-fatal: worst case, settings reset on next launch.
		}
	}
}
