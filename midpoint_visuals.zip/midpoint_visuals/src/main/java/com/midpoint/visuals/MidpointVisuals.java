package com.midpoint.visuals;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Midpoint Visuals is a purely client-side cosmetic mod:
 * - Block highlight on the block you are currently looking at (no ESP through walls)
 * - A movable inventory / armor durability HUD overlay
 * - Colored "glow" overlay on items inside inventory screens
 *
 * There is no common (server-relevant) logic, so this entrypoint only exists
 * to satisfy Fabric's loader and to provide a shared logger instance.
 */
public class MidpointVisuals implements ModInitializer {

	public static final String MOD_ID = "midpoint_visuals";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("Midpoint Visuals initialized (common).");
	}
}
