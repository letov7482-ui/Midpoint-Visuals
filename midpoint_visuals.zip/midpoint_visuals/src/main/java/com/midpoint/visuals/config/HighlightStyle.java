package com.midpoint.visuals.config;

/**
 * Fill style used inside the outlined block for the BlockHighlight module.
 */
public enum HighlightStyle {
	SOLID("Solid"),
	COSMIC("Cosmic"),
	BLACKHOLE("Black Hole");

	public final String label;

	HighlightStyle(String label) {
		this.label = label;
	}

	public HighlightStyle next() {
		HighlightStyle[] values = values();
		return values[(this.ordinal() + 1) % values.length];
	}
}
