package com.midpoint.visuals.config;

/**
 * Plain data holder serialized to/from config/midpoint_visuals.json by ConfigManager.
 * Every module defaults to OFF.
 */
public class MidpointConfig {

	// --- BlockHighlight ---
	public ModuleState blockHighlightState = ModuleState.OFF;
	public int blockHighlightColor = 0xFF39FF6A; // default neon green, ARGB
	public HighlightStyle blockHighlightStyle = HighlightStyle.SOLID;

	// --- Inventory HUD ---
	public ModuleState inventoryHudState = ModuleState.OFF;
	public int hudX = 12;
	public int hudY = 12;
	public int hudAccentColor = 0xFF39FF6A;

	// --- Item Glow ---
	public ModuleState itemGlowState = ModuleState.OFF;
	public GlowColor itemGlowColor = GlowColor.PURPLE;
}
