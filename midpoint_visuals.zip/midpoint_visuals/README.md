# Midpoint Visuals

Client-side cosmetic mod for Fabric 1.21.4 (Java 21, official Mojang mappings).

**Modules (all default OFF, cycle OFF → ON → RANDOM in the GUI):**

1. **Block Highlight** — outlines only the block currently under your crosshair
   (the client's own vanilla ray trace result — never renders through walls)
   with a neon border and a fill style: Solid / Cosmic / Black Hole. Custom
   color palette including black.
2. **Inventory HUD** — a movable panel titled "Midpoint Visuals" showing your
   hotbar and armor durability bars. Reposition it from the mod's GUI via the
   **"Edit HUD Position"** button — drag the panel anywhere or snap it to a
   corner.
3. **Item Glow** — tints occupied inventory slots with a soft colored overlay
   (Purple / Black / Yellow / Blue), purely cosmetic.

Open the settings GUI with **Right Shift**, or through **ModMenu** if it's installed.

## Building

Requires JDK 21 and an internet connection (Fabric/Mojang/Maven Central repos).

```bash
./gradlew build
```

The compiled mod jar will be in `build/libs/`.

The project ships its own Gradle wrapper (`gradlew` / `gradlew.bat` /
`gradle/wrapper/gradle-wrapper.jar`, pinned to Gradle 8.14), so no local
Gradle install is required — the wrapper downloads the correct Gradle
version automatically on first run.

## Notes on correctness

This source was hand-written against the **official Mojang mappings** for
1.21.4 and the Fabric API surface as of that version. Two areas are the most
likely to need a small adjustment if Mojang/Fabric shifted method names after
this was written:

- The HUD layer API (`HudElementRegistry` / `HudElement` in
  `net.fabricmc.fabric.api.client.rendering.v1`) — Minecraft's HUD rendering
  pipeline changed more than once across the 1.21.x line.
- The exact `fabric_version` pin in `gradle.properties` — check
  https://fabricmc.net/develop/ for the correct build matching Minecraft
  1.21.4 and update it if Gradle can't resolve the dependency.

If `./gradlew build` reports a missing symbol, running
`./gradlew genSources` and checking the decompiled class in question will
almost always show the correct current name to swap in.

## Compatibility

Client-only mod (`"environment": "client"` in `fabric.mod.json`). Works on
PC Fabric installs as well as mobile Fabric-based launchers (Pojav, Zalith,
Mojo, FCL) since it uses no server-side logic and keeps rendering batched
per-frame.

## GitHub Actions

The build is automated via `.github/workflows/build.yml`. It runs on every
push/PR to `main`/`master` and can also be triggered manually.

**How to run it manually:**

1. Open the repository on GitHub and go to the **Actions** tab.
2. Select the **Build Midpoint Visuals** workflow in the left sidebar.
3. Click **Run workflow**, pick the branch, and confirm.
4. Once the run finishes, open it and download the compiled jar from the
   **Artifacts** section (`midpoint-visuals-build`).

**What the workflow does:**

1. Checks out the repository.
2. If `midpoint_visuals.zip` exists at the repo root, unpacks it into the
   `midpoint_visuals/` folder (if the folder already exists directly in the
   repo instead of a zip, that's used as-is).
3. Sets up JDK 21 (Temurin) with Gradle dependency caching.
4. Runs `./gradlew build --warning-mode all --stacktrace` from inside
   `midpoint_visuals/`.
5. Uploads the resulting jar(s) from `build/libs/` as a workflow artifact.

No manual steps are required in the repository itself — just keep either
`midpoint_visuals.zip` or an unpacked `midpoint_visuals/` folder at the
repository root, and the workflow figures out the rest.
