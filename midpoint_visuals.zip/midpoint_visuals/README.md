# Midpoint Visuals

Client-side cosmetic mod for Fabric 1.21.4 (Java 21, official Mojang mappings).

**Modules (all default OFF, cycle OFF → ON → RANDOM in the GUI):**

1. **Block Highlight** — outlines only the block currently under your crosshair
   (the client's own vanilla ray trace result — never renders through walls)
   with a neon border and a fill style: Solid / Cosmic / Black Hole. Custom
   color palette including black.
2. **Inventory HUD** — a movable panel titled "Midpoint Visuals" showing your
   hotbar and armor durability bars. Reposition it from the mod's GUI via the
   **"Edit HUD Position"** button — drag the panel anywhere or snap it to a
   corner.
3. **Item Glow** — tints occupied inventory slots with a soft colored overlay
   (Purple / Black / Yellow / Blue), purely cosmetic.

Open the settings GUI with **Right Shift**, or through **ModMenu** if it's installed.

## Building

Requires JDK 21 and an internet connection (Fabric/Mojang/Maven Central repos).

```bash
./gradlew build
```

The compiled mod jar will be in `build/libs/`.

> This project doesn't ship a Gradle wrapper jar. Run `gradle wrapper` once
> with a local Gradle 8.x install to generate `gradlew` / `gradlew.bat` /
> `gradle/wrapper/gradle-wrapper.jar`, or open the folder directly in your
> IDE (IntelliJ IDEA recognizes `build.gradle` and will bootstrap Loom itself).

## Notes on correctness

This source was hand-written against the **official Mojang mappings** for
1.21.4 and the Fabric API surface as of that version. Two areas are the most
likely to need a small adjustment if Mojang/Fabric shifted method names after
this was written:

- The HUD layer API (`HudElementRegistry` / `HudElement` in
  `net.fabricmc.fabric.api.client.rendering.v1`) — Minecraft's HUD rendering
  pipeline changed more than once across the 1.21.x line.
- The exact `fabric_version` pin in `gradle.properties` — check
  https://fabricmc.net/develop/ for the correct build matching Minecraft
  1.21.4 and update it if Gradle can't resolve the dependency.

If `./gradlew build` reports a missing symbol, running
`./gradlew genSources` and checking the decompiled class in question will
almost always show the correct current name to swap in.

## Compatibility

Client-only mod (`"environment": "client"` in `fabric.mod.json`). Works on
PC Fabric installs as well as mobile Fabric-based launchers (Pojav, Zalith,
Mojo, FCL) since it uses no server-side logic and keeps rendering batched
per-frame.
