package net.midpoint.visuals.shader;

import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import net.fabricmc.fabric.api.client.rendering.v1.CoreShaderRegistrationCallback;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;

import java.io.IOException;
import java.util.function.Supplier;

/**
 * Registers Midpoint Visuals' custom core shader ("midpoint_glow") through
 * {@link CoreShaderRegistrationCallback}, as required for any shader used
 * outside the vanilla render-type shader set.
 *
 * @author Midpoint
 */
public final class ShaderManager {

	public static final ResourceLocation GLOW_SHADER_ID =
			ResourceLocation.fromNamespaceAndPath("midpoint_visuals", "midpoint_glow");

	private static ShaderInstance glowShader;

	private ShaderManager() {
	}

	public static void init() {
		CoreShaderRegistrationCallback.EVENT.register(context -> {
			context.register(GLOW_SHADER_ID, DefaultVertexFormat.POSITION_COLOR, ShaderManager::onGlowLoaded);
		});
	}

	private static void onGlowLoaded(ShaderInstance shader) {
		glowShader = shader;
	}

	public static Supplier<ShaderInstance> glowShaderSupplier() {
		return () -> glowShader;
	}

	public static VertexFormat glowFormat() {
		return DefaultVertexFormat.POSITION_COLOR;
	}
}
