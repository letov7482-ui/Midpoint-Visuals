package net.midpoint.visuals.cosmetics;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import net.midpoint.visuals.config.ConfigManager;

/**
 * Renders the cosmetic hat on top of the player's head, following the head's
 * own rotation so it turns naturally with the model.
 *
 * @author Midpoint
 */
public class HatFeatureRenderer extends RenderLayer<PlayerRenderState, PlayerModel> {

	private static final ResourceLocation HAT_TEXTURE =
			ResourceLocation.fromNamespaceAndPath("midpoint_visuals", "textures/models/hats/top_hat.png");

	private final HatModel hatModel;

	public HatFeatureRenderer(RenderLayerParent<PlayerRenderState, PlayerModel> parent, HatModel hatModel) {
		super(parent);
		this.hatModel = hatModel;
	}

	@Override
	public void render(PoseStack poseStack, MultiBufferSource bufferSource, int packedLight,
			PlayerRenderState renderState, float yRot, float xRot) {
		if (!ConfigManager.CONFIG.hatsEnabled || "none".equals(ConfigManager.CONFIG.selectedHat)) {
			return;
		}

		PlayerModel model = getParentModel();

		poseStack.pushPose();
		// Follow the player's head bone so the hat rotates with the head.
		model.head.translateAndRotate(poseStack);
		poseStack.translate(0.0, -0.05, 0.0);

		var consumer = bufferSource.getBuffer(RenderType.entityCutoutNoCull(HAT_TEXTURE));
		hatModel.part().render(poseStack, consumer, packedLight, OverlayTexture.NO_OVERLAY);

		poseStack.popPose();
	}
}
