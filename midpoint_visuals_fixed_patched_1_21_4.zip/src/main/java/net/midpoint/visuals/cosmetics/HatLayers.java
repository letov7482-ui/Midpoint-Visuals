package net.midpoint.visuals.cosmetics;

import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;

/**
 * @author Midpoint
 */
public final class HatLayers {

	public static final ModelLayerLocation HAT = new ModelLayerLocation(
			ResourceLocation.fromNamespaceAndPath("midpoint_visuals", "hat"), "main");

	private HatLayers() {
	}

	public static void register() {
		EntityModelLayerRegistry.registerModelLayer(HAT, HatModel::createLayerDefinition);
	}
}
