package net.midpoint.visuals.cosmetics;

import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/**
 * A minimal cosmetic top-hat cube mesh worn on top of the player's head.
 *
 * @author Midpoint
 */
public final class HatModel {

	public static final String LAYER_NAME = "midpoint_hat";

	private final ModelPart root;

	public HatModel(ModelPart root) {
		this.root = root;
	}

	public static LayerDefinition createLayerDefinition() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition parts = mesh.getRoot();
		parts.addOrReplaceChild("hat",
				CubeListBuilder.create()
						.texOffs(0, 0)
						.addBox(-4.0f, -8.0f, -4.0f, 8.0f, 6.0f, 8.0f),
				PartPose.offset(0.0f, 0.0f, 0.0f));
		return LayerDefinition.create(mesh, 64, 32);
	}

	public ModelPart part() {
		return root;
	}
}
