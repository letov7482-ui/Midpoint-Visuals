package net.midpoint.visuals.emotes;

/**
 * @author Midpoint
 */
public enum EmoteType {
	NONE,
	SPIN_STAND,
	SPIN_SIT
}
