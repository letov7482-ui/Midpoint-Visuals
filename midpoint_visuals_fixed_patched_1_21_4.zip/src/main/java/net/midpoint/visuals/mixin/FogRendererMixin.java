package net.midpoint.visuals.mixin;

import net.midpoint.visuals.environment.EnvironmentModule;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.FogParameters;
import net.minecraft.client.renderer.FogRenderer;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Overrides the vanilla fog colour after it has been computed, so this mod
 * still respects biome / potion fog blending and only tints the final
 * result. Reading the interpolated pulse via {@code EnvironmentModule}
 * keeps the tint frame-rate independent.
 *
 * <p>Since Minecraft 1.21.2, {@code FogRenderer#setupFog} takes the base
 * fog colour as a {@code Vector4f} parameter and returns an immutable
 * {@link FogParameters} record instead of pushing the colour straight to
 * {@code RenderSystem}. This mixin therefore injects at {@code RETURN} and
 * substitutes a new {@code FogParameters} with the tinted colour, keeping
 * every other computed value (start/end/shape/alpha) untouched.</p>
 *
 * <p>NOTE: {@code FogRenderer#setupFog} is one of the vanilla methods most
 * likely to shift signature between 1.21.x patches as Mojang continues the
 * render-pipeline split; if this mixin fails to apply, paste the resulting
 * compiler error and it can be re-targeted quickly.</p>
 *
 * @author Midpoint
 */
@Mixin(FogRenderer.class)
public class FogRendererMixin {

	@Inject(method = "setupFog", at = @At("RETURN"), cancellable = true)
	private static void midpointVisuals$tintFog(Camera camera, FogRenderer.FogMode fogMode, Vector4f color,
			float viewDistance, boolean thickFog, float partialTick,
			CallbackInfoReturnable<FogParameters> cir) {
		if (!EnvironmentModule.isActive()) {
			return;
		}

		FogParameters original = cir.getReturnValue();
		int tintColor = EnvironmentModule.getFogColor();
		float pulse = 0.6f + 0.4f * EnvironmentModule.getPulse(partialTick);
		float r = ((tintColor >> 16) & 0xFF) / 255f * pulse;
		float g = ((tintColor >> 8) & 0xFF) / 255f * pulse;
		float b = (tintColor & 0xFF) / 255f * pulse;

		cir.setReturnValue(new FogParameters(
				original.start(),
				original.end(),
				original.shape(),
				r, g, b,
				original.alpha()));
	}
}
