package net.midpoint.visuals.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import net.midpoint.visuals.environment.EnvironmentModule;
import net.minecraft.client.Camera;
import net.minecraft.client.renderer.FogRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Overrides the vanilla fog colour after it has been computed, so this mod
 * still respects biome / potion fog blending and only tints the final
 * result. Reading the interpolated pulse via {@code EnvironmentModule}
 * keeps the tint frame-rate independent.
 *
 * <p>NOTE: {@code FogRenderer#setupFog} is one of the vanilla methods most
 * likely to shift signature between 1.21.x patches as Mojang continues the
 * render-pipeline split; if this mixin fails to apply, paste the resulting
 * compiler error and it can be re-targeted quickly.</p>
 *
 * @author Midpoint
 */
@Mixin(FogRenderer.class)
public class FogRendererMixin {

	@Inject(method = "setupFog", at = @At("TAIL"))
	private static void midpointVisuals$tintFog(Camera camera, FogRenderer.FogMode fogMode,
			float viewDistance, boolean thickFog, float partialTick, CallbackInfo ci) {
		if (!EnvironmentModule.isActive()) {
			return;
		}
		int color = EnvironmentModule.getFogColor();
		float pulse = 0.6f + 0.4f * EnvironmentModule.getPulse(partialTick);
		float r = ((color >> 16) & 0xFF) / 255f * pulse;
		float g = ((color >> 8) & 0xFF) / 255f * pulse;
		float b = (color & 0xFF) / 255f * pulse;
		RenderSystem.setShaderFogColor(r, g, b);
	}
}
