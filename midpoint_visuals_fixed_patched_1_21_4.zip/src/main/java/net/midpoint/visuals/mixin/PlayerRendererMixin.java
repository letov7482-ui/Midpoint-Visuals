package net.midpoint.visuals.mixin;

import net.midpoint.visuals.cosmetics.HatFeatureRenderer;
import net.midpoint.visuals.cosmetics.HatLayers;
import net.midpoint.visuals.cosmetics.HatModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.PlayerRenderer;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Injects the {@link HatFeatureRenderer} into every {@link PlayerRenderer}
 * instance right after vanilla construction finishes.
 *
 * @author Midpoint
 */
@Mixin(PlayerRenderer.class)
public abstract class PlayerRendererMixin
		extends LivingEntityRenderer<AbstractClientPlayer, PlayerRenderState, PlayerModel> {

	public PlayerRendererMixin(EntityRendererProvider.Context context, PlayerModel model, float shadowRadius) {
		super(context, model, shadowRadius);
	}

	@Inject(method = "<init>", at = @At("TAIL"))
	private void midpointVisuals$addHatLayer(EntityRendererProvider.Context context, boolean slim, CallbackInfo ci) {
		HatModel hatModel = new HatModel(context.bakeLayer(HatLayers.HAT));
		this.addLayer(new HatFeatureRenderer(this, hatModel));
	}
}
