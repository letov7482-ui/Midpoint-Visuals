package net.midpoint.visuals.mixin;

import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.emotes.EmoteManager;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.entity.state.PlayerRenderState;
import net.minecraft.util.Mth;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Layers the emote spin rotation on top of vanilla pose calculation. Runs
 * strictly after {@code super.setupAnim} so it overrides, rather than
 * fights with, the vanilla walk/swim/idle animation for the duration of
 * the emote.
 *
 * @author Midpoint
 */
@Mixin(PlayerModel.class)
public abstract class PlayerModelMixin extends HumanoidModel<PlayerRenderState> {

	public PlayerModelMixin(ModelPart root) {
		super(root);
	}

	@Inject(method = "setupAnim", at = @At("TAIL"))
	private void midpointVisuals$applyEmote(PlayerRenderState state, CallbackInfo ci) {
		if (!ConfigManager.CONFIG.emotesEnabled || !EmoteManager.isSpinning()) {
			return;
		}

		// The render state already carries this frame's interpolated tick,
		// so a full-strength (1.0) sample of the emote's own internal
		// tick/tick-delta buffer gives a smooth per-frame angle here.
		float angleRad = Mth.PI * 2.0f * (EmoteManager.getSpinAngleDegrees(1.0f) / 360.0f);

		this.body.yRot = angleRad;
		this.head.yRot = angleRad;
		this.hat.yRot = angleRad;
		this.rightArm.yRot = angleRad;
		this.leftArm.yRot = angleRad;
		this.rightLeg.yRot = angleRad;
		this.leftLeg.yRot = angleRad;

		if (EmoteManager.isSitting()) {
			float bendRad = -Mth.HALF_PI;
			this.rightLeg.xRot = bendRad;
			this.leftLeg.xRot = bendRad;
			this.rightLeg.z = 2.0f;
			this.leftLeg.z = 2.0f;
			this.body.y += 6.0f;
			this.head.y += 6.0f;
			this.hat.y += 6.0f;
			this.rightArm.y += 6.0f;
			this.leftArm.y += 6.0f;
		}
	}
}
