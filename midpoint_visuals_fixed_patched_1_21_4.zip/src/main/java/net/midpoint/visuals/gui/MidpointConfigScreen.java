package net.midpoint.visuals.gui;

import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.config.ModConfig;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Simple vanilla settings screen (no cloth-config dependency) exposing a
 * toggle for every module. Rendered exclusively through {@link GuiGraphics}.
 *
 * @author Midpoint
 */
public class MidpointConfigScreen extends Screen {

	private final Screen parent;
	private static final int ROW_HEIGHT = 24;

	public MidpointConfigScreen(Screen parent) {
		super(Component.literal("Midpoint Visuals"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		ModConfig cfg = ConfigManager.CONFIG;
		int centerX = this.width / 2;
		int startY = 40;
		int width = 220;

		addToggle(centerX, startY, width, "Environment", () -> cfg.environmentEnabled, v -> cfg.environmentEnabled = v);
		addToggle(centerX, startY + ROW_HEIGHT, width, "HUD Overlay", () -> cfg.hudEnabled, v -> cfg.hudEnabled = v);
		addToggle(centerX, startY + ROW_HEIGHT * 2, width, "Glow Particles", () -> cfg.fxEnabled, v -> cfg.fxEnabled = v);
		addToggle(centerX, startY + ROW_HEIGHT * 3, width, "Hats", () -> cfg.hatsEnabled, v -> cfg.hatsEnabled = v);
		addToggle(centerX, startY + ROW_HEIGHT * 4, width, "Emotes", () -> cfg.emotesEnabled, v -> cfg.emotesEnabled = v);
		addToggle(centerX, startY + ROW_HEIGHT * 5, width, "Glow Shader", () -> cfg.shaderGlowEnabled, v -> cfg.shaderGlowEnabled = v);

		this.addRenderableWidget(Button.builder(Component.literal("Done"), b -> {
					ConfigManager.save();
					this.minecraft.setScreen(this.parent);
				})
				.bounds(centerX - width / 2, startY + ROW_HEIGHT * 6 + 12, width, 20)
				.build());
	}

	private void addToggle(int centerX, int y, int width, String label,
			java.util.function.BooleanSupplier getter, java.util.function.Consumer<Boolean> setter) {
		Button[] holder = new Button[1];
		Button button = Button.builder(Component.literal(label + ": " + (getter.getAsBoolean() ? "ON" : "OFF")), b -> {
					boolean next = !getter.getAsBoolean();
					setter.accept(next);
					b.setMessage(Component.literal(label + ": " + (next ? "ON" : "OFF")));
				})
				.bounds(centerX - width / 2, y, width, 20)
				.build();
		holder[0] = button;
		this.addRenderableWidget(button);
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
		this.renderBackground(graphics, mouseX, mouseY, partialTick);
		super.render(graphics, mouseX, mouseY, partialTick);
		graphics.drawCenteredString(this.font, this.title, this.width / 2, 16, 0xFFFFFF);
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void onClose() {
		ConfigManager.save();
		this.minecraft.setScreen(this.parent);
	}
}
