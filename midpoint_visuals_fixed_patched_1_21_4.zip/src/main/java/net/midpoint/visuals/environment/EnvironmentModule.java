package net.midpoint.visuals.environment;

import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.config.ModConfig;
import net.minecraft.util.Mth;

/**
 * Holds tick-interpolated environment state (fog / sky tint) that the
 * {@code FogRendererMixin} reads from every frame. Advancing state on the
 * client tick keeps rendering frame-rate independent when combined with
 * {@link Mth#lerp(float, float, float)} against {@code tickDelta}.
 *
 * @author Midpoint
 */
public final class EnvironmentModule {

	private static float previousPulse = 0f;
	private static float currentPulse = 0f;
	private static int tickCounter = 0;

	private EnvironmentModule() {
	}

	/** Called once per client tick from {@link net.midpoint.visuals.core.MidpointVisualsClient}. */
	public static void tick() {
		ModConfig cfg = ConfigManager.CONFIG;
		if (!cfg.environmentEnabled) {
			return;
		}
		tickCounter++;
		previousPulse = currentPulse;
		currentPulse = (float) (0.5 + 0.5 * Math.sin(tickCounter / 20.0));
	}

	/** Interpolated 0..1 pulse value for the current frame. */
	public static float getPulse(float tickDelta) {
		return Mth.lerp(tickDelta, previousPulse, currentPulse);
	}

	public static boolean isActive() {
		return ConfigManager.CONFIG.environmentEnabled;
	}

	public static int getFogColor() {
		return ConfigManager.CONFIG.fogColor;
	}

	public static float getFogDensityMultiplier() {
		return ConfigManager.CONFIG.fogDensityMultiplier;
	}

	public static boolean isSkyTintEnabled() {
		return ConfigManager.CONFIG.tintSky;
	}

	public static int getSkyTintColor() {
		return ConfigManager.CONFIG.skyTintColor;
	}
}
