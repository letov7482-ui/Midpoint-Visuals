package net.midpoint.visuals.fx;

import net.fabricmc.fabric.api.particle.v1.FabricParticleTypes;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;

/**
 * Registers Midpoint Visuals' custom glow particle type.
 *
 * @author Midpoint
 */
public final class ModParticles {

	public static final SimpleParticleType MIDPOINT_GLOW = FabricParticleTypes.simple();

	private ModParticles() {
	}

	public static void register() {
		Registry.register(
				BuiltInRegistries.PARTICLE_TYPE,
				ResourceLocation.fromNamespaceAndPath("midpoint_visuals", "midpoint_glow"),
				MIDPOINT_GLOW
		);
	}
}
