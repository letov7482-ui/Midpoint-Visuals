package net.midpoint.visuals.fx;

import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleProvider;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.SpriteSet;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.core.particles.SimpleParticleType;

/**
 * A small additive glow speck used by the {@code fx} module. Colour is
 * supplied by {@link net.midpoint.visuals.config.ModConfig#particleColor}.
 *
 * @author Midpoint
 */
public class GlowParticle extends TextureSheetParticle {

	protected GlowParticle(ClientLevel level, double x, double y, double z,
			double dx, double dy, double dz, int argb) {
		super(level, x, y, z, dx, dy, dz);
		this.xd = dx;
		this.yd = dy * 0.2 + 0.02;
		this.zd = dz;
		this.quadSize = 0.08f + this.random.nextFloat() * 0.05f;
		this.lifetime = 20 + this.random.nextInt(10);
		this.hasPhysics = false;
		float r = ((argb >> 16) & 0xFF) / 255f;
		float g = ((argb >> 8) & 0xFF) / 255f;
		float b = (argb & 0xFF) / 255f;
		this.setColor(r, g, b);
		this.setAlpha(0.9f);
	}

	@Override
	public ParticleRenderType getRenderType() {
		return ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
	}

	@Override
	public void tick() {
		super.tick();
		this.alpha = 1.0f - ((float) this.age / this.lifetime);
	}

	public static class FactoryProvider implements ParticleProvider<SimpleParticleType> {
		private final SpriteSet sprites;

		public FactoryProvider(SpriteSet sprites) {
			this.sprites = sprites;
		}

		@Override
		public Particle createParticle(SimpleParticleType type, ClientLevel level,
				double x, double y, double z, double dx, double dy, double dz) {
			int argb = net.midpoint.visuals.config.ConfigManager.CONFIG.particleColor;
			GlowParticle particle = new GlowParticle(level, x, y, z, dx, dy, dz, argb);
			particle.pickSprite(sprites);
			return particle;
		}
	}
}
