package net.midpoint.visuals.fx;

import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.config.ModConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;

/**
 * Registers the glow particle factory and periodically spawns particles
 * around the local player when the {@code fx} module is enabled.
 *
 * @author Midpoint
 */
public final class FxManager {

	private FxManager() {
	}

	public static void registerClient() {
		ParticleFactoryRegistry.getInstance().register(ModParticles.MIDPOINT_GLOW, GlowParticle.FactoryProvider::new);
	}

	/** Called once per client tick. */
	public static void tick() {
		ModConfig cfg = ConfigManager.CONFIG;
		if (!cfg.fxEnabled) {
			return;
		}
		Minecraft client = Minecraft.getInstance();
		Player player = client.player;
		if (player == null || client.level == null) {
			return;
		}
		for (int i = 0; i < Math.max(0, cfg.particlesPerTick); i++) {
			double ox = (client.level.random.nextDouble() - 0.5) * 0.6;
			double oy = client.level.random.nextDouble() * 1.8;
			double oz = (client.level.random.nextDouble() - 0.5) * 0.6;
			client.level.addParticle(ModParticles.MIDPOINT_GLOW,
					player.getX() + ox, player.getY() + oy, player.getZ() + oz,
					0.0, 0.01, 0.0);
		}
	}
}
