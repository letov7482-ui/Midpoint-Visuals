package net.midpoint.visuals.core;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.cosmetics.HatLayers;
import net.midpoint.visuals.emotes.EmoteManager;
import net.midpoint.visuals.environment.EnvironmentModule;
import net.midpoint.visuals.fx.FxManager;
import net.midpoint.visuals.fx.ModParticles;
import net.midpoint.visuals.gui.MidpointConfigScreen;
import net.midpoint.visuals.hud.HudOverlay;
import net.midpoint.visuals.shader.ShaderManager;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;

/**
 * Midpoint Visuals - client entrypoint. Initializes every module and wires
 * the shared client tick loop.
 *
 * @author Midpoint
 */
public class MidpointVisualsClient implements ClientModInitializer {

	private static final KeyMapping OPEN_GUI = new KeyMapping(
			"key.midpoint_visuals.open_gui",
			InputConstants.Type.KEYSYM,
			InputConstants.KEY_G,
			"category.midpoint_visuals");

	@Override
	public void onInitializeClient() {
		ConfigManager.load();

		// registries first
		ModParticles.register();
		HatLayers.register();
		ShaderManager.init();

		// runtime hooks
		FxManager.registerClient();
		HudOverlay.register();
		EmoteManager.registerClient();
		KeyBindingHelper.registerKeyBinding(OPEN_GUI);

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			EnvironmentModule.tick();
			FxManager.tick();

			while (OPEN_GUI.consumeClick()) {
				Minecraft mc = Minecraft.getInstance();
				if (mc.screen == null) {
					mc.setScreen(new MidpointConfigScreen(null));
				}
			}
		});
	}
}
