package net.midpoint.visuals.config;

import com.terraformersmc.modmenu.api.ConfigScreenFactory;
import com.terraformersmc.modmenu.api.ModMenuApi;
import net.midpoint.visuals.gui.MidpointConfigScreen;

/**
 * @author Midpoint
 */
public class ModMenuIntegration implements ModMenuApi {

	@Override
	public ConfigScreenFactory<?> getModConfigScreenFactory() {
		return MidpointConfigScreen::new;
	}
}
