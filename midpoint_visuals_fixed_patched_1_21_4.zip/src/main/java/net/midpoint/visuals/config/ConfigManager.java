package net.midpoint.visuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Loads and persists {@link ModConfig} as JSON under the game's config directory.
 *
 * @author Midpoint
 */
public final class ConfigManager {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path CONFIG_PATH = FabricLoader.getInstance()
			.getConfigDir()
			.resolve("midpoint_visuals.json");

	public static ModConfig CONFIG = new ModConfig();

	private ConfigManager() {
	}

	public static void load() {
		if (!Files.exists(CONFIG_PATH)) {
			CONFIG = new ModConfig();
			save();
			return;
		}
		try (Reader reader = Files.newBufferedReader(CONFIG_PATH, StandardCharsets.UTF_8)) {
			ModConfig loaded = GSON.fromJson(reader, ModConfig.class);
			CONFIG = loaded != null ? loaded : new ModConfig();
		} catch (IOException e) {
			CONFIG = new ModConfig();
		}
	}

	public static void save() {
		try {
			Path dir = CONFIG_PATH.getParent();
			if (dir != null && !Files.exists(dir)) {
				Files.createDirectories(dir);
			}
			try (Writer writer = Files.newBufferedWriter(CONFIG_PATH, StandardCharsets.UTF_8)) {
				GSON.toJson(CONFIG, writer);
			}
		} catch (IOException ignored) {
			// Best-effort persistence; a failed save should never crash the client.
		}
	}
}
