package net.midpoint.visuals.config;

/**
 * Midpoint Visuals - central configuration object.
 * Serialized to/from JSON by {@link ConfigManager} via GSON.
 *
 * @author Midpoint
 */
public class ModConfig {

	// --- environment ---
	public boolean environmentEnabled = false;
	public int fogColor = 0xFF9B30FF;
	public float fogDensityMultiplier = 1.0f;
	public boolean tintSky = false;
	public int skyTintColor = 0xFF101018;

	// --- hud ---
	public boolean hudEnabled = true;
	public int hudX = 8;
	public int hudY = 8;
	public int hudAccentColor = 0xFF9B30FF;

	// --- fx (glow particles) ---
	public boolean fxEnabled = true;
	public int particleColor = 0xFF66E0FF;
	public int particlesPerTick = 1;

	// --- cosmetics (hats) ---
	public boolean hatsEnabled = true;
	public String selectedHat = "none";

	// --- emotes ---
	public boolean emotesEnabled = true;
	public int emoteSpinDurationTicks = 40;

	// --- shader ---
	public boolean shaderGlowEnabled = true;
}
