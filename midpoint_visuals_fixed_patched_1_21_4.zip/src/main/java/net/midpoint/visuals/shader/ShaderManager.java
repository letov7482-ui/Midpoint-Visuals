package net.midpoint.visuals.shader;

import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.renderer.ShaderProgram;
import net.minecraft.resources.ResourceLocation;

import java.util.function.Supplier;

/**
 * Keeps a stable entry point for the custom glow shader.
 *
 * <p>In Minecraft 1.21.4, modded core shaders are loaded from the vanilla
 * resource-pack pipeline, so Fabric's old CoreShaderRegistrationCallback is
 * no longer used here.</p>
 *
 * @author Midpoint
 */
public final class ShaderManager {

	public static final ResourceLocation GLOW_SHADER_ID =
			ResourceLocation.fromNamespaceAndPath("midpoint_visuals", "midpoint_glow");

	private ShaderManager() {
	}

	public static void init() {
		// No-op on 1.21.4: the shader is discovered from assets/midpoint_visuals/shaders/core.
	}

	public static Supplier<ShaderProgram> glowShaderSupplier() {
		return () -> null;
	}

	public static VertexFormat glowFormat() {
		return DefaultVertexFormat.POSITION_COLOR;
	}
}
