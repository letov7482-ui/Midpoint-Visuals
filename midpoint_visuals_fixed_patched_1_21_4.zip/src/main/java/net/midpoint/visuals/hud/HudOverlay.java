package net.midpoint.visuals.hud;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.midpoint.visuals.config.ConfigManager;
import net.midpoint.visuals.config.ModConfig;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Draws the Midpoint Visuals HUD panel entirely through {@link GuiGraphics},
 * driven by {@link HudRenderCallback} (Fabric API) rather than any mixin.
 *
 * @author Midpoint
 */
public final class HudOverlay {

	private static final int PANEL_WIDTH = 90;
	private static final int PANEL_HEIGHT = 40;

	private HudOverlay() {
	}

	public static void register() {
		HudRenderCallback.EVENT.register(HudOverlay::render);
	}

	private static void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
		ModConfig cfg = ConfigManager.CONFIG;
		if (!cfg.hudEnabled) {
			return;
		}
		Minecraft client = Minecraft.getInstance();
		if (client.options.hideGui || client.player == null) {
			return;
		}

		int x = cfg.hudX;
		int y = cfg.hudY;
		int accent = cfg.hudAccentColor;

		graphics.fill(x, y, x + PANEL_WIDTH, y + PANEL_HEIGHT, 0xA0101014);
		graphics.fill(x, y, x + PANEL_WIDTH, y + 2, accent);

		graphics.drawString(client.font, Component.literal("Midpoint Visuals"), x + 4, y + 6, 0xFFFFFF, false);

		float health = client.player.getHealth();
		float maxHealth = client.player.getMaxHealth();
		float ratio = maxHealth > 0 ? Mth_clamp01(health / maxHealth) : 0f;
		int barWidth = PANEL_WIDTH - 8;
		int filled = Math.round(barWidth * ratio);

		graphics.fill(x + 4, y + 20, x + 4 + barWidth, y + 26, 0x66000000);
		graphics.fill(x + 4, y + 20, x + 4 + filled, y + 26, accent);
	}

	private static float Mth_clamp01(float v) {
		if (v < 0f) return 0f;
		if (v > 1f) return 1f;
		return v;
	}
}
