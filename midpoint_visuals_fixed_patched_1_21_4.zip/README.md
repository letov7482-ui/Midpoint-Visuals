# Midpoint Visuals

Client-side cosmetic mod for Minecraft 1.21.4 (Fabric). Author: **Midpoint**.

## Modules

| Package | Purpose |
|---|---|
| `core` | `ClientModInitializer`, wires every module together and runs the shared client tick loop. |
| `config` | GSON JSON config (`ModConfig`/`ConfigManager`) + Mod Menu integration + settings screen. |
| `shader` | Registers the `midpoint_glow` core shader via `CoreShaderRegistrationCallback`. |
| `environment` | Tick-interpolated fog/sky tint state, applied by `FogRendererMixin`. |
| `hud` | On-screen HUD panel via Fabric API's `HudRenderCallback`, drawn with `GuiGraphics`. |
| `fx` | Custom glow particle type + spawner around the player. |
| `cosmetics` | Wearable cosmetic hat rendered through a `RenderLayer` (feature renderer) on `PlayerRenderer`. |
| `emotes` | Two dance emotes (standing 360° spin, sitting 360° spin) driven by keybinds and applied to `PlayerModel` bones. |
| `mixin` | `PlayerRendererMixin` (adds hat layer), `PlayerModelMixin` (applies emote rotation), `FogRendererMixin` (fog tint), `GameRendererMixin` (FOV kick during emotes). |

## Build

```
./gradlew build
```

Output jar lands in `build/libs/`.

## Known risk areas for first CI run

Minecraft's rendering internals (`FogRenderer`, `GameRenderer#getFov`, the `RenderLayer`/`FeatureRenderer`
generics, and `PlayerRenderState`) have been under active refactor across 1.21.x. All of these were written
against the best available knowledge of the 1.21.4 Mojang mappings, but exact method signatures can shift by
patch. If the build fails on any of these, paste the compiler error and it can be re-targeted quickly - this
is normal for cutting-edge Mojmap modding and does not indicate a structural problem with the rest of the mod.
